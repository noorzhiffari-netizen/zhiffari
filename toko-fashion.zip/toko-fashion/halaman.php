<?php
require_once __DIR__ . '/includes/init.php';
$h = row('SELECT * FROM halaman WHERE slug=? AND aktif=1', [$_GET['slug'] ?? '']);
if (!$h) { http_response_code(404); $h = ['judul' => 'Halaman tidak ditemukan', 'isi' => '<p>Halaman yang Anda cari tidak tersedia.</p>']; }
$pageTitle = $h['judul'];
require __DIR__ . '/includes/header.php';
?>
<div class="container">
    <h1 class="page-title"><?= e($h['judul']) ?></h1>
    <div class="content-html"><?= $h['isi'] ?></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
