<?php
require_once __DIR__ . '/includes/init.php';
$p = row('SELECT p.*, k.nama kategori_nama, k.slug kategori_slug FROM produk p LEFT JOIN kategori k ON k.id=p.kategori_id WHERE p.slug=? AND p.aktif=1', [$_GET['slug'] ?? '']);
if (!$p) { http_response_code(404); $pageTitle = 'Produk tidak ditemukan'; require __DIR__ . '/includes/header.php'; echo '<div class="container"><div class="panel" style="margin-top:30px">Produk tidak ditemukan. <a href="' . url('produk.php') . '"><b>Lihat semua produk</b></a></div></div>'; require __DIR__ . '/includes/footer.php'; exit; }
$pageTitle = $p['nama'];
$h = harga_efektif($p);
$disc = $h < $p['harga'];
$uk = daftar_ukuran($p);
$terkait = rows('SELECT * FROM produk WHERE aktif=1 AND kategori_id<=>? AND id<>? ORDER BY RAND() LIMIT 4', [$p['kategori_id'], $p['id']]);
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<div class="detail">
    <div class="pic"><img src="<?= e(img($p['gambar'])) ?>" alt="<?= e($p['nama']) ?>"></div>
    <div>
        <?php if ($p['kategori_nama']): ?><a class="muted" href="<?= url('produk.php?kategori=' . urlencode($p['kategori_slug'])) ?>"><?= e($p['kategori_nama']) ?></a><?php endif; ?>
        <h1><?= e($p['nama']) ?></h1>
        <div class="harga"><?= rupiah($h) ?><?php if ($disc): ?><s><?= rupiah($p['harga']) ?></s><?php endif; ?></div>
        <p class="muted">Terjual <?= (int)$p['terjual'] ?> &bull; Stok: <?= $p['stok'] > 0 ? (int)$p['stok'] : '<b style="color:#b91c1c">Habis</b>' ?></p>
        <?php if ($p['warna']): ?><p><b>Warna:</b> <?= e($p['warna']) ?></p><?php endif; ?>

        <?php if ($p['stok'] > 0): ?>
        <form method="post" action="<?= url('keranjang.php') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="aksi" value="tambah">
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <?php if ($uk): ?>
                <b>Pilih ukuran:</b>
                <div class="sizes">
                    <?php foreach ($uk as $i => $u): ?>
                        <input type="radio" name="ukuran" id="u<?= $i ?>" value="<?= e($u) ?>" <?= $i === 0 ? 'required' : '' ?>>
                        <label for="u<?= $i ?>"><?= e($u) ?></label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <b>Jumlah:</b><br>
            <div class="qty" style="margin:8px 0 18px"><button type="button" data-d="-">&minus;</button><input type="number" name="qty" value="1" min="1" max="<?= (int)$p['stok'] ?>"><button type="button" data-d="+">+</button></div>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
                <button class="btn btn-outline" type="submit">+ Keranjang</button>
                <button class="btn btn-accent" type="submit" name="langsung" value="1">Beli Sekarang</button>
            </div>
        </form>
        <?php else: ?>
            <div class="alert alert-danger">Maaf, produk ini sedang habis.</div>
        <?php endif; ?>
        <div class="desc"><h3>Deskripsi</h3><?= nl2br(e($p['deskripsi'])) ?></div>
    </div>
</div>
<?php if ($terkait): ?>
    <div class="sec-head"><h2>Produk Terkait</h2></div>
    <div class="grid"><?php foreach ($terkait as $t) echo product_card($t); ?></div>
<?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
