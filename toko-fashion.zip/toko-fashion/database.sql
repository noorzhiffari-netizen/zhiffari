-- ============================================================
-- Database Toko Online Fashion (MySQL / MariaDB)
-- Impor file ini lewat phpMyAdmin (tab Import) atau:
--   mysql -u root -p < database.sql
-- ============================================================
CREATE DATABASE IF NOT EXISTS toko_fashion CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE toko_fashion;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS pesanan_item, pesanan, produk, kategori, banner, halaman, pengaturan, users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  telepon VARCHAR(30) DEFAULT NULL,
  alamat TEXT DEFAULT NULL,
  role ENUM('super_admin','admin','staf_produk','staf_pesanan','pelanggan') NOT NULL DEFAULT 'pelanggan',
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE kategori (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  deskripsi VARCHAR(255) DEFAULT NULL,
  gambar VARCHAR(255) DEFAULT NULL,
  urutan INT NOT NULL DEFAULT 0,
  aktif TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE produk (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kategori_id INT DEFAULT NULL,
  nama VARCHAR(160) NOT NULL,
  slug VARCHAR(180) NOT NULL UNIQUE,
  deskripsi TEXT,
  harga DECIMAL(12,0) NOT NULL DEFAULT 0,
  harga_diskon DECIMAL(12,0) NOT NULL DEFAULT 0,
  stok INT NOT NULL DEFAULT 0,
  ukuran VARCHAR(120) DEFAULT NULL,
  warna VARCHAR(120) DEFAULT NULL,
  gambar VARCHAR(255) DEFAULT NULL,
  unggulan TINYINT(1) NOT NULL DEFAULT 0,
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  terjual INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (kategori_id) REFERENCES kategori(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE banner (
  id INT AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(150) NOT NULL,
  subjudul VARCHAR(255) DEFAULT NULL,
  gambar VARCHAR(255) DEFAULT NULL,
  link VARCHAR(255) DEFAULT NULL,
  tombol VARCHAR(50) DEFAULT 'Belanja Sekarang',
  urutan INT NOT NULL DEFAULT 0,
  aktif TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE halaman (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(100) NOT NULL UNIQUE,
  judul VARCHAR(150) NOT NULL,
  isi MEDIUMTEXT,
  aktif TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE pengaturan (
  kunci VARCHAR(60) PRIMARY KEY,
  nilai TEXT
) ENGINE=InnoDB;

CREATE TABLE pesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kode VARCHAR(30) NOT NULL UNIQUE,
  user_id INT DEFAULT NULL,
  nama VARCHAR(100) NOT NULL,
  telepon VARCHAR(30) NOT NULL,
  alamat TEXT NOT NULL,
  metode_bayar VARCHAR(100) NOT NULL,
  subtotal DECIMAL(12,0) NOT NULL DEFAULT 0,
  ongkir DECIMAL(12,0) NOT NULL DEFAULT 0,
  total DECIMAL(12,0) NOT NULL DEFAULT 0,
  status ENUM('menunggu_pembayaran','diproses','dikirim','selesai','dibatalkan') NOT NULL DEFAULT 'menunggu_pembayaran',
  catatan TEXT DEFAULT NULL,
  resi VARCHAR(80) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE pesanan_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pesanan_id INT NOT NULL,
  produk_id INT DEFAULT NULL,
  nama_produk VARCHAR(160) NOT NULL,
  harga DECIMAL(12,0) NOT NULL,
  ukuran VARCHAR(30) DEFAULT NULL,
  qty INT NOT NULL,
  FOREIGN KEY (pesanan_id) REFERENCES pesanan(id) ON DELETE CASCADE,
  FOREIGN KEY (produk_id) REFERENCES produk(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- DATA AWAL
-- Semua akun contoh memakai password: password   (WAJIB diganti!)
-- ------------------------------------------------------------
INSERT INTO users (nama,email,password,telepon,role) VALUES
('Super Admin','admin@tokofashion.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','081200000001','super_admin'),
('Admin Toko','manajer@tokofashion.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','081200000002','admin'),
('Staf Produk','produk@tokofashion.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','081200000003','staf_produk'),
('Staf Pesanan','pesanan@tokofashion.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','081200000004','staf_pesanan'),
('Pelanggan Contoh','pelanggan@tokofashion.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','081200000005','pelanggan');

INSERT INTO kategori (nama,slug,deskripsi,urutan) VALUES
('Pakaian Pria','pakaian-pria','Kaos, kemeja, jaket, dan celana pria',1),
('Pakaian Wanita','pakaian-wanita','Dress, blouse, rok, dan outer wanita',2),
('Sepatu','sepatu','Sneakers, formal, dan sandal',3),
('Tas','tas','Ransel, tote bag, dan sling bag',4),
('Aksesoris','aksesoris','Topi, ikat pinggang, jam tangan, dan kacamata',5),
('Hijab & Muslim','hijab-muslim','Hijab, gamis, dan busana muslim',6);

INSERT INTO produk (kategori_id,nama,slug,deskripsi,harga,harga_diskon,stok,ukuran,warna,unggulan,terjual) VALUES
(1,'Kaos Polos Premium Cotton','kaos-polos-premium-cotton','Kaos cotton combed 30s yang lembut, adem, dan tidak mudah melar. Cocok untuk harian.',89000,69000,80,'S,M,L,XL,XXL','Hitam, Putih, Navy',1,120),
(1,'Kemeja Flannel Kotak','kemeja-flannel-kotak','Kemeja flannel tebal dengan motif kotak klasik. Nyaman dipakai sendiri atau sebagai outer.',189000,0,40,'M,L,XL','Merah, Biru',1,54),
(1,'Jaket Bomber Casual','jaket-bomber-casual','Jaket bomber bahan parasut dengan lapisan dalam halus, ringan namun hangat.',259000,219000,25,'M,L,XL','Hitam, Olive',1,33),
(1,'Celana Chino Slim Fit','celana-chino-slim-fit','Celana chino stretch dengan potongan slim fit yang rapi untuk kerja maupun santai.',199000,0,50,'28,30,32,34,36','Khaki, Hitam, Navy',0,61),
(2,'Dress Midi Floral','dress-midi-floral','Dress midi motif bunga dengan bahan jatuh dan ringan. Elegan untuk berbagai acara.',229000,189000,30,'S,M,L','Navy Floral, Pink Floral',1,47),
(2,'Blouse Satin Elegan','blouse-satin-elegan','Blouse satin dengan kilau lembut dan kerah modern. Mudah dipadukan.',169000,0,35,'S,M,L,XL','Cream, Sage, Hitam',1,28),
(2,'Rok Plisket Panjang','rok-plisket-panjang','Rok plisket panjang dengan pinggang karet, nyaman dan tidak mudah kusut.',139000,119000,45,'All Size','Hitam, Mocha, Dusty Pink',0,76),
(3,'Sneakers Urban Putih','sneakers-urban-putih','Sneakers putih serbaguna dengan sol empuk dan outsole anti-slip.',349000,299000,30,'39,40,41,42,43,44','Putih',1,88),
(3,'Sepatu Pantofel Kulit','sepatu-pantofel-kulit','Pantofel kulit sintetis premium dengan jahitan rapi untuk tampilan formal.',329000,0,18,'40,41,42,43','Hitam, Coklat',0,19),
(4,'Ransel Laptop Anti Air','ransel-laptop-anti-air','Ransel dengan kompartemen laptop 15 inci, bahan anti air, dan tali bahu empuk.',239000,199000,35,'',  'Hitam, Abu',1,64),
(4,'Sling Bag Kulit Mini','sling-bag-kulit-mini','Sling bag mini dengan tali adjustable, muat HP, dompet, dan kebutuhan kecil.',159000,0,28,'', 'Hitam, Tan',0,41),
(5,'Topi Baseball Bordir','topi-baseball-bordir','Topi baseball dengan bordir rapi dan tali belakang yang bisa diatur.',69000,0,100,'All Size','Hitam, Krem, Hijau',0,150),
(5,'Ikat Pinggang Kulit','ikat-pinggang-kulit','Ikat pinggang kulit asli dengan gesper stainless anti karat.',119000,99000,60,'100,110,120','Hitam, Coklat',0,37),
(6,'Hijab Pashmina Ceruty','hijab-pashmina-ceruty','Pashmina ceruty babydoll yang jatuh, tidak menerawang, dan mudah dibentuk.',59000,49000,120,'All Size','Mocca, Navy, Dusty Pink, Hitam',1,210),
(6,'Gamis Katun Polos','gamis-katun-polos','Gamis katun adem dengan resleting depan busui friendly dan saku samping.',269000,0,22,'M,L,XL','Sage, Hitam, Dusty Pink',0,26);

INSERT INTO banner (judul,subjudul,link,tombol,urutan) VALUES
('Koleksi Terbaru Musim Ini','Tampil percaya diri dengan gaya terbaru. Diskon hingga 30% untuk produk pilihan.','produk.php','Belanja Sekarang',1),
('Sepatu & Tas Favorit','Lengkapi penampilanmu dengan sepatu dan tas berkualitas.','produk.php?kategori=sepatu','Lihat Sepatu',2),
('Gratis Ongkir','Nikmati gratis ongkir untuk pembelian di atas batas minimum.','produk.php','Mulai Belanja',3);

INSERT INTO halaman (slug,judul,isi) VALUES
('tentang-kami','Tentang Kami','<p>Kami adalah toko fashion online yang menghadirkan pakaian, sepatu, tas, dan aksesoris berkualitas dengan harga bersahabat.</p><p>Misi kami sederhana: membuat setiap orang tampil percaya diri setiap hari.</p>'),
('kontak','Hubungi Kami','<p>Tim kami siap membantu Anda setiap hari pukul 09.00 - 21.00 WIB. Hubungi kami lewat WhatsApp, email, atau media sosial yang tertera di bagian bawah halaman.</p>'),
('cara-belanja','Cara Belanja','<ol><li>Pilih produk dan ukuran yang diinginkan.</li><li>Masukkan ke keranjang, lalu lanjut ke checkout.</li><li>Isi data pengiriman dan pilih metode pembayaran.</li><li>Lakukan pembayaran sesuai instruksi.</li><li>Pesanan diproses dan dikirim ke alamat Anda.</li></ol>'),
('kebijakan-pengembalian','Kebijakan Pengembalian','<p>Barang dapat ditukar maksimal 7 hari setelah diterima apabila terdapat cacat produksi atau salah ukuran, selama label dan kemasan masih utuh.</p>');

INSERT INTO pengaturan (kunci,nilai) VALUES
('nama_toko','Toko Fashion'),
('tagline','Gaya terbaik, harga bersahabat'),
('deskripsi','Belanja pakaian, sepatu, tas, dan aksesoris fashion terbaru dengan harga terjangkau.'),
('warna_utama','#111827'),
('warna_aksen','#e11d48'),
('logo',''),
('email','halo@tokofashion.test'),
('telepon','081234567890'),
('whatsapp','6281234567890'),
('alamat','Jl. Contoh No. 123, Jakarta'),
('instagram','https://instagram.com/'),
('facebook','https://facebook.com/'),
('ongkir','15000'),
('gratis_ongkir_min','300000'),
('metode_bayar','Transfer Bank BCA|No. rek 1234567890 a.n. Toko Fashion\nTransfer Bank Mandiri|No. rek 9876543210 a.n. Toko Fashion\nBayar di Tempat (COD)|Bayar tunai saat barang tiba'),
('footer_teks','Semua hak dilindungi.');
