<?php
require_once __DIR__ . '/includes/init.php';
$u = current_user();
if (!$u) redirect(url('login.php'));
$o = row('SELECT * FROM pesanan WHERE kode=? AND user_id=?', [$_GET['kode'] ?? '', $u['id']]);
if (!$o) redirect(url('akun.php'));
$metode = null;
foreach (metode_bayar_list() as $m) if ($m['nama'] === $o['metode_bayar']) $metode = $m;
$pageTitle = 'Pesanan Berhasil';
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<div class="panel auth" style="max-width:600px;text-align:center">
    <div style="font-size:3rem">&#10004;&#65039;</div>
    <h1>Terima kasih, pesanan diterima!</h1>
    <p>Kode pesanan Anda: <b style="font-size:1.2rem"><?= e($o['kode']) ?></b></p>
    <p>Total pembayaran: <b style="color:var(--accent);font-size:1.3rem"><?= rupiah($o['total']) ?></b></p>
    <div class="alert alert-info" style="text-align:left">
        <b><?= e($o['metode_bayar']) ?></b><br><?= e($metode['ket'] ?? '') ?>
        <?php if (stripos($o['metode_bayar'], 'COD') === false): ?><br>Lakukan pembayaran, lalu hubungi kami via WhatsApp dengan menyebutkan kode pesanan.<?php endif; ?>
    </div>
    <a class="btn" href="<?= url('pesanan.php?kode=' . urlencode($o['kode'])) ?>">Lihat Detail Pesanan</a>
    <a class="btn btn-outline" href="<?= url('produk.php') ?>">Belanja Lagi</a>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
