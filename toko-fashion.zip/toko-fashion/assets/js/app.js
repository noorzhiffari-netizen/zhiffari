document.addEventListener('DOMContentLoaded', function () {
  // menu mobile
  var t = document.querySelector('.menu-toggle'), n = document.querySelector('nav.main');
  if (t && n) t.addEventListener('click', function () { n.classList.toggle('open'); });

  // slider banner
  var slides = document.querySelectorAll('.slide'), dots = document.querySelectorAll('.dots button'), i = 0, timer;
  function show(k) {
    if (!slides.length) return;
    i = (k + slides.length) % slides.length;
    slides.forEach(function (s, x) { s.classList.toggle('on', x === i); });
    dots.forEach(function (d, x) { d.classList.toggle('on', x === i); });
  }
  function auto() { clearInterval(timer); if (slides.length > 1) timer = setInterval(function () { show(i + 1); }, 5000); }
  dots.forEach(function (d, x) { d.addEventListener('click', function () { show(x); auto(); }); });
  show(0); auto();

  // tombol jumlah
  document.querySelectorAll('.qty').forEach(function (q) {
    var inp = q.querySelector('input'), max = parseInt(inp.getAttribute('max') || '999', 10);
    q.querySelectorAll('button').forEach(function (b) {
      b.addEventListener('click', function () {
        var v = parseInt(inp.value || '1', 10) + (b.dataset.d === '+' ? 1 : -1);
        inp.value = Math.max(1, Math.min(max, v));
        if (inp.dataset.auto) inp.form.submit();
      });
    });
  });

  // konfirmasi hapus
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) { if (!confirm(el.dataset.confirm)) e.preventDefault(); });
  });
  document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) { if (!confirm(f.dataset.confirm)) e.preventDefault(); });
  });
});
