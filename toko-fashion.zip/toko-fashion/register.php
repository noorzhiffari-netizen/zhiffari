<?php
require_once __DIR__ . '/includes/init.php';
if (current_user()) redirect(url('akun.php'));
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $telp = trim($_POST['telepon'] ?? '');
    $pw = $_POST['password'] ?? '';
    if ($nama === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Nama dan email yang valid wajib diisi.';
    elseif (strlen($pw) < 6) $err = 'Password minimal 6 karakter.';
    elseif ($pw !== ($_POST['password2'] ?? '')) $err = 'Konfirmasi password tidak sama.';
    elseif (val('SELECT COUNT(*) FROM users WHERE email=?', [$email])) $err = 'Email sudah terdaftar.';
    else {
        q('INSERT INTO users (nama,email,password,telepon,role) VALUES (?,?,?,?,?)', [$nama, $email, password_hash($pw, PASSWORD_DEFAULT), $telp, 'pelanggan']);
        $u = row('SELECT * FROM users WHERE id=?', [db()->lastInsertId()]);
        login_user($u);
        flash('success', 'Pendaftaran berhasil. Selamat datang!');
        $to = $_SESSION['after_login'] ?? url('akun.php');
        unset($_SESSION['after_login']);
        redirect($to);
    }
}
$pageTitle = 'Daftar';
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<div class="panel auth">
    <h2>Buat Akun Baru</h2>
    <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <div class="form-row"><label>Nama Lengkap</label><input type="text" name="nama" required value="<?= e($_POST['nama'] ?? '') ?>"></div>
        <div class="form-row"><label>Email</label><input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></div>
        <div class="form-row"><label>No. Telepon</label><input type="tel" name="telepon" value="<?= e($_POST['telepon'] ?? '') ?>"></div>
        <div class="form-row"><label>Password</label><input type="password" name="password" required minlength="6"></div>
        <div class="form-row"><label>Ulangi Password</label><input type="password" name="password2" required minlength="6"></div>
        <button class="btn btn-block" type="submit">Daftar</button>
    </form>
    <p style="text-align:center">Sudah punya akun? <a href="<?= url('login.php') ?>"><b>Masuk</b></a></p>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
