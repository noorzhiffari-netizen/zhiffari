<?php
// ===== KONFIGURASI DATABASE =====
// Sesuaikan dengan server MySQL Anda.
define('DB_HOST', 'localhost');
define('DB_NAME', 'toko_fashion');
define('DB_USER', 'root');
define('DB_PASS', '');

// Folder upload gambar
define('UPLOAD_DIR', __DIR__ . '/uploads/');

// BASE_URL terdeteksi otomatis (mis. /toko-fashion). Isi manual jika perlu.
$__root = rtrim(str_replace('\\', '/', (string)realpath($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
$__dir  = str_replace('\\', '/', (string)realpath(__DIR__));
define('BASE_URL', rtrim(str_replace($__root, '', $__dir), '/'));

// Set ke true saat pengembangan untuk menampilkan error
ini_set('display_errors', '0');
