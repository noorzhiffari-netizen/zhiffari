<?php
require_once __DIR__ . '/includes/init.php';
$u = current_user();
if (!$u) { $_SESSION['after_login'] = url('akun.php'); redirect(url('login.php')); }
$o = row('SELECT * FROM pesanan WHERE kode=? AND user_id=?', [$_GET['kode'] ?? '', $u['id']]);
if (!$o) { flash('danger', 'Pesanan tidak ditemukan.'); redirect(url('akun.php')); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'batal') {
    if ($o['status'] === 'menunggu_pembayaran' && ubah_status_pesanan($o['id'], 'dibatalkan')) flash('success', 'Pesanan dibatalkan.');
    else flash('danger', 'Pesanan tidak dapat dibatalkan.');
    redirect(url('pesanan.php?kode=' . urlencode($o['kode'])));
}
$items = rows('SELECT * FROM pesanan_item WHERE pesanan_id=?', [$o['id']]);
$pageTitle = 'Pesanan ' . $o['kode'];
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<h1 class="page-title">Pesanan <?= e($o['kode']) ?> <?= status_badge($o['status']) ?></h1>
<div class="two">
    <div class="panel">
        <table class="tbl resp">
            <thead><tr><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Total</th></tr></thead>
            <?php foreach ($items as $it): ?>
                <tr><td><?= e($it['nama_produk']) ?><?= $it['ukuran'] ? ' <small class="muted">(' . e($it['ukuran']) . ')</small>' : '' ?></td><td><?= rupiah($it['harga']) ?></td><td><?= (int)$it['qty'] ?></td><td><?= rupiah($it['harga'] * $it['qty']) ?></td></tr>
            <?php endforeach; ?>
        </table>
        <div class="sum-row"><span>Subtotal</span><span><?= rupiah($o['subtotal']) ?></span></div>
        <div class="sum-row"><span>Ongkos kirim</span><span><?= rupiah($o['ongkir']) ?></span></div>
        <div class="sum-row total"><span>Total</span><span><?= rupiah($o['total']) ?></span></div>
    </div>
    <div class="panel">
        <h3>Informasi</h3>
        <p><b>Tanggal:</b> <?= tgl($o['created_at']) ?></p>
        <p><b>Penerima:</b> <?= e($o['nama']) ?><br><?= e($o['telepon']) ?></p>
        <p><b>Alamat:</b><br><?= nl2br(e($o['alamat'])) ?></p>
        <p><b>Pembayaran:</b> <?= e($o['metode_bayar']) ?></p>
        <?php if ($o['resi']): ?><p><b>No. Resi:</b> <?= e($o['resi']) ?></p><?php endif; ?>
        <?php if ($o['status'] === 'menunggu_pembayaran'): ?>
            <form method="post" data-confirm="Yakin membatalkan pesanan ini?"><?= csrf_field() ?><input type="hidden" name="aksi" value="batal"><button class="btn btn-outline btn-block" type="submit">Batalkan Pesanan</button></form>
        <?php endif; ?>
    </div>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
