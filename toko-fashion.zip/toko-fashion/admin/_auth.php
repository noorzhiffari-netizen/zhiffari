<?php
// Wajib di-include paling awal oleh setiap halaman admin. Set $perm sebelum include.
require_once __DIR__ . '/../includes/init.php';
require_admin($perm ?? 'dashboard');
$me = current_user();
