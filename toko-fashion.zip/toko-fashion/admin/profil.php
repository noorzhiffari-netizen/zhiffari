<?php
$perm = 'dashboard'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'profil') {
        $nama = trim($_POST['nama'] ?? '');
        if ($nama === '') flash('danger', 'Nama wajib diisi.');
        else { q('UPDATE users SET nama=?, telepon=? WHERE id=?', [$nama, trim($_POST['telepon'] ?? ''), $me['id']]); flash('success', 'Profil diperbarui.'); }
    }
    if ($do === 'password') {
        $baru = $_POST['baru'] ?? '';
        if (!password_verify($_POST['lama'] ?? '', $me['password'])) flash('danger', 'Password lama salah.');
        elseif (strlen($baru) < 6) flash('danger', 'Password baru minimal 6 karakter.');
        elseif ($baru !== ($_POST['baru2'] ?? '')) flash('danger', 'Konfirmasi password tidak sama.');
        else { q('UPDATE users SET password=? WHERE id=?', [password_hash($baru, PASSWORD_DEFAULT), $me['id']]); flash('success', 'Password berhasil diubah.'); }
    }
    redirect('profil.php');
}
$title = 'Profil Saya';
require __DIR__ . '/_header.php';
?>
<div class="grid2" style="align-items:start">
<div class="box"><h3>Data Diri</h3>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="profil">
        <div class="form-row"><label>Nama</label><input type="text" name="nama" required value="<?= e($me['nama']) ?>"></div>
        <div class="form-row"><label>Email</label><input type="email" value="<?= e($me['email']) ?>" disabled></div>
        <div class="form-row"><label>Telepon</label><input type="tel" name="telepon" value="<?= e($me['telepon']) ?>"></div>
        <div class="form-row"><label>Peran</label><input type="text" value="<?= e(role_label($me['role'])) ?>" disabled></div>
        <button class="btn" type="submit">Simpan</button>
    </form></div>
<div class="box"><h3>Ganti Password</h3>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="password">
        <div class="form-row"><label>Password Lama</label><input type="password" name="lama" required></div>
        <div class="form-row"><label>Password Baru</label><input type="password" name="baru" required minlength="6"></div>
        <div class="form-row"><label>Ulangi Password Baru</label><input type="password" name="baru2" required minlength="6"></div>
        <button class="btn" type="submit">Ubah Password</button>
    </form></div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
