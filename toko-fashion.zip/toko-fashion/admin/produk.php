<?php
$perm = 'produk'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $nama = trim($_POST['nama'] ?? '');
        $harga = max(0, (int)($_POST['harga'] ?? 0));
        $diskon = max(0, (int)($_POST['harga_diskon'] ?? 0));
        if ($nama === '') { flash('danger', 'Nama produk wajib diisi.'); redirect('produk.php' . ($id ? '?edit=' . $id : '?tambah=1')); }
        if ($diskon >= $harga) $diskon = 0;
        $lama = $id ? row('SELECT * FROM produk WHERE id=?', [$id]) : null;
        $gambar = upload_image('gambar', $lama['gambar'] ?? '');
        $kat = (int)($_POST['kategori_id'] ?? 0) ?: null;
        $f = [$kat, $nama, trim($_POST['deskripsi'] ?? ''), $harga, $diskon, max(0, (int)($_POST['stok'] ?? 0)),
              trim($_POST['ukuran'] ?? ''), trim($_POST['warna'] ?? ''), $gambar, isset($_POST['unggulan']) ? 1 : 0, isset($_POST['aktif']) ? 1 : 0];
        if ($lama) {
            q('UPDATE produk SET kategori_id=?,nama=?,deskripsi=?,harga=?,harga_diskon=?,stok=?,ukuran=?,warna=?,gambar=?,unggulan=?,aktif=? WHERE id=?', array_merge($f, [$id]));
            flash('success', 'Produk diperbarui.');
        } else {
            $slug = unique_slug('produk', $nama);
            q('INSERT INTO produk (kategori_id,nama,deskripsi,harga,harga_diskon,stok,ukuran,warna,gambar,unggulan,aktif,slug) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', array_merge($f, [$slug]));
            flash('success', 'Produk ditambahkan.');
        }
        redirect('produk.php');
    }
    if ($do === 'hapus') {
        $p = row('SELECT * FROM produk WHERE id=?', [(int)$_POST['id']]);
        if ($p) { delete_image($p['gambar']); q('DELETE FROM produk WHERE id=?', [$p['id']]); flash('success', 'Produk dihapus.'); }
        redirect('produk.php');
    }
    if ($do === 'toggle') {
        q('UPDATE produk SET aktif=1-aktif WHERE id=?', [(int)$_POST['id']]);
        redirect('produk.php');
    }
}

$cats = rows('SELECT * FROM kategori ORDER BY urutan,nama');
$form = isset($_GET['tambah']) || isset($_GET['edit']);
$title = $form ? (isset($_GET['edit']) ? 'Ubah Produk' : 'Tambah Produk') : 'Produk';
require __DIR__ . '/_header.php';

if ($form):
    $p = isset($_GET['edit']) ? row('SELECT * FROM produk WHERE id=?', [(int)$_GET['edit']]) : null;
    if (isset($_GET['edit']) && !$p) { echo '<div class="alert alert-danger">Produk tidak ditemukan.</div>'; require __DIR__ . '/_footer.php'; exit; }
    $v = fn($k, $d = '') => e($p[$k] ?? $d);
?>
<div class="box">
<form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?><input type="hidden" name="do" value="simpan"><input type="hidden" name="id" value="<?= (int)($p['id'] ?? 0) ?>">
    <div class="grid2">
        <div class="form-row"><label>Nama Produk *</label><input type="text" name="nama" required value="<?= $v('nama') ?>"></div>
        <div class="form-row"><label>Kategori</label>
            <select name="kategori_id"><option value="">- Tanpa kategori -</option>
                <?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= ($p['kategori_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>><?= e($c['nama']) ?></option><?php endforeach; ?>
            </select></div>
    </div>
    <div class="grid3">
        <div class="form-row"><label>Harga (Rp) *</label><input type="number" name="harga" min="0" required value="<?= $v('harga', 0) ?>"></div>
        <div class="form-row"><label>Harga Diskon (Rp, 0 = tanpa diskon)</label><input type="number" name="harga_diskon" min="0" value="<?= $v('harga_diskon', 0) ?>"></div>
        <div class="form-row"><label>Stok</label><input type="number" name="stok" min="0" value="<?= $v('stok', 0) ?>"></div>
    </div>
    <div class="grid2">
        <div class="form-row"><label>Ukuran (pisahkan koma, kosongkan jika tidak ada)</label><input type="text" name="ukuran" placeholder="S,M,L,XL" value="<?= $v('ukuran') ?>"></div>
        <div class="form-row"><label>Warna (teks bebas)</label><input type="text" name="warna" placeholder="Hitam, Putih" value="<?= $v('warna') ?>"></div>
    </div>
    <div class="form-row"><label>Deskripsi</label><textarea name="deskripsi"><?= $v('deskripsi') ?></textarea></div>
    <div class="form-row"><label>Gambar Produk (JPG/PNG/WEBP, maks 3 MB)</label><input type="file" name="gambar" accept="image/*">
        <?php if (!empty($p['gambar'])): ?><img class="preview" src="<?= e(img($p['gambar'])) ?>" alt=""><?php endif; ?></div>
    <div class="chk">
        <label><input type="checkbox" name="unggulan" <?= !empty($p['unggulan']) ? 'checked' : '' ?>> Produk unggulan (tampil di beranda)</label>
        <label><input type="checkbox" name="aktif" <?= (!$p || $p['aktif']) ? 'checked' : '' ?>> Aktif / tampil di toko</label>
    </div>
    <button class="btn" type="submit">Simpan</button> <a class="btn btn-line" href="produk.php">Batal</a>
</form>
</div>
<?php else:
    $cari = trim($_GET['q'] ?? ''); $kf = (int)($_GET['kat'] ?? 0); $page = max(1, (int)($_GET['page'] ?? 1)); $per = 15;
    $w = ['1=1']; $par = [];
    if ($cari !== '') { $w[] = 'p.nama LIKE ?'; $par[] = "%$cari%"; }
    if ($kf) { $w[] = 'p.kategori_id=?'; $par[] = $kf; }
    $ws = implode(' AND ', $w);
    $total = (int)val("SELECT COUNT(*) FROM produk p WHERE $ws", $par);
    $list = rows("SELECT p.*, k.nama kat FROM produk p LEFT JOIN kategori k ON k.id=p.kategori_id WHERE $ws ORDER BY p.id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $par);
?>
<div class="box">
    <div class="toolbar">
        <form method="get">
            <input type="text" name="q" placeholder="Cari produk..." value="<?= e($cari) ?>">
            <select name="kat"><option value="">Semua kategori</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $kf == $c['id'] ? 'selected' : '' ?>><?= e($c['nama']) ?></option><?php endforeach; ?></select>
            <button class="btn btn-line" type="submit">Filter</button>
        </form>
        <a class="btn" href="?tambah=1">+ Tambah Produk</a>
    </div>
    <div class="tbl-wrap"><table class="tbl">
        <tr><th>Gambar</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th><th>Aksi</th></tr>
        <?php foreach ($list as $p): ?>
        <tr>
            <td><img class="thumb" src="<?= e(img($p['gambar'])) ?>" alt=""></td>
            <td><b><?= e($p['nama']) ?></b><?= $p['unggulan'] ? ' <span class="tag">&#9733; unggulan</span>' : '' ?></td>
            <td><?= e($p['kat'] ?? '-') ?></td>
            <td><?= rupiah($p['harga']) ?><?= ($p['harga_diskon'] > 0) ? '<br><small style="color:#e11d48">Diskon ' . rupiah($p['harga_diskon']) . '</small>' : '' ?></td>
            <td><?= (int)$p['stok'] ?></td>
            <td><span class="tag <?= $p['aktif'] ? 'ok' : 'off' ?>"><?= $p['aktif'] ? 'Aktif' : 'Nonaktif' ?></span></td>
            <td style="white-space:nowrap">
                <a class="btn btn-sm btn-line" href="?edit=<?= $p['id'] ?>">Ubah</a>
                <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn btn-sm btn-line" type="submit"><?= $p['aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?></button></form>
                <form method="post" style="display:inline" data-confirm="Hapus produk ini secara permanen?"><?= csrf_field() ?><input type="hidden" name="do" value="hapus"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="btn btn-sm btn-red" type="submit">Hapus</button></form>
            </td>
        </tr>
        <?php endforeach; if (!$list) echo '<tr><td colspan="7" class="muted">Belum ada produk.</td></tr>'; ?>
    </table></div>
    <?= pager($total, $per, $page) ?>
</div>
<?php endif; require __DIR__ . '/_footer.php'; ?>
