<?php
$perm = 'pelanggan'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'toggle') {
    q("UPDATE users SET aktif=1-aktif WHERE id=? AND role='pelanggan'", [(int)$_POST['id']]);
    flash('success', 'Status pelanggan diubah.');
    redirect('pelanggan.php');
}
$title = 'Pelanggan';
$cari = trim($_GET['q'] ?? ''); $page = max(1, (int)($_GET['page'] ?? 1)); $per = 20;
$w = "role='pelanggan'"; $par = [];
if ($cari !== '') { $w .= ' AND (nama LIKE ? OR email LIKE ?)'; $par = ["%$cari%", "%$cari%"]; }
$total = (int)val("SELECT COUNT(*) FROM users WHERE $w", $par);
$list = rows("SELECT u.*, (SELECT COUNT(*) FROM pesanan p WHERE p.user_id=u.id) jml, (SELECT COALESCE(SUM(total),0) FROM pesanan p WHERE p.user_id=u.id AND p.status IN ('diproses','dikirim','selesai')) belanja FROM users u WHERE $w ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $par);
require __DIR__ . '/_header.php';
?>
<div class="box">
    <div class="toolbar"><form method="get"><input type="text" name="q" placeholder="Nama / email" value="<?= e($cari) ?>"><button class="btn btn-line" type="submit">Cari</button></form></div>
    <div class="tbl-wrap"><table class="tbl">
        <tr><th>Nama</th><th>Email</th><th>Telepon</th><th>Pesanan</th><th>Total Belanja</th><th>Daftar</th><th>Status</th><?php if (can('pengguna')): ?><th></th><?php endif; ?></tr>
        <?php foreach ($list as $u): ?>
        <tr><td><b><?= e($u['nama']) ?></b></td><td><?= e($u['email']) ?></td><td><?= e($u['telepon']) ?></td><td><?= (int)$u['jml'] ?></td><td><?= rupiah($u['belanja']) ?></td><td><?= tgl($u['created_at'], false) ?></td>
            <td><span class="tag <?= $u['aktif'] ? 'ok' : 'off' ?>"><?= $u['aktif'] ? 'Aktif' : 'Diblokir' ?></span></td>
            <?php if (can('pengguna')): ?><td><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= $u['id'] ?>"><button class="btn btn-sm btn-line" type="submit"><?= $u['aktif'] ? 'Blokir' : 'Aktifkan' ?></button></form></td><?php endif; ?></tr>
        <?php endforeach; if (!$list) echo '<tr><td colspan="8" class="muted">Belum ada pelanggan.</td></tr>'; ?>
    </table></div>
    <?= pager($total, $per, $page) ?>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
