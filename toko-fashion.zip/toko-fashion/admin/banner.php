<?php
$perm = 'banner'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $judul = trim($_POST['judul'] ?? '');
        if ($judul === '') { flash('danger', 'Judul banner wajib diisi.'); redirect('banner.php'); }
        $lama = $id ? row('SELECT * FROM banner WHERE id=?', [$id]) : null;
        $d = [$judul, trim($_POST['subjudul'] ?? ''), upload_image('gambar', $lama['gambar'] ?? ''), trim($_POST['link'] ?? ''), trim($_POST['tombol'] ?? ''), (int)($_POST['urutan'] ?? 0), isset($_POST['aktif']) ? 1 : 0];
        if ($lama) { q('UPDATE banner SET judul=?,subjudul=?,gambar=?,link=?,tombol=?,urutan=?,aktif=? WHERE id=?', array_merge($d, [$id])); flash('success', 'Banner diperbarui.'); }
        else { q('INSERT INTO banner (judul,subjudul,gambar,link,tombol,urutan,aktif) VALUES (?,?,?,?,?,?,?)', $d); flash('success', 'Banner ditambahkan.'); }
        redirect('banner.php');
    }
    if ($do === 'hapus') {
        $b = row('SELECT * FROM banner WHERE id=?', [(int)$_POST['id']]);
        if ($b) { delete_image($b['gambar']); q('DELETE FROM banner WHERE id=?', [$b['id']]); flash('success', 'Banner dihapus.'); }
        redirect('banner.php');
    }
}
$title = 'Banner Beranda';
$edit = isset($_GET['edit']) ? row('SELECT * FROM banner WHERE id=?', [(int)$_GET['edit']]) : null;
$list = rows('SELECT * FROM banner ORDER BY urutan,id');
require __DIR__ . '/_header.php';
?>
<div class="grid2" style="align-items:start">
<div class="box">
    <h3><?= $edit ? 'Ubah Banner' : 'Tambah Banner' ?></h3>
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="do" value="simpan"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="form-row"><label>Judul *</label><input type="text" name="judul" required value="<?= e($edit['judul'] ?? '') ?>"></div>
        <div class="form-row"><label>Sub judul</label><input type="text" name="subjudul" value="<?= e($edit['subjudul'] ?? '') ?>"></div>
        <div class="grid2">
            <div class="form-row"><label>Link tombol</label><input type="text" name="link" placeholder="produk.php?kategori=sepatu" value="<?= e($edit['link'] ?? '') ?>"></div>
            <div class="form-row"><label>Teks tombol</label><input type="text" name="tombol" value="<?= e($edit['tombol'] ?? 'Belanja Sekarang') ?>"></div>
        </div>
        <div class="form-row"><label>Urutan</label><input type="number" name="urutan" value="<?= (int)($edit['urutan'] ?? 0) ?>"></div>
        <div class="form-row"><label>Gambar latar (disarankan lebar 1600px; kosong = warna gradasi)</label><input type="file" name="gambar" accept="image/*"><?php if (!empty($edit['gambar'])): ?><img class="preview" src="<?= e(img($edit['gambar'])) ?>" alt=""><?php endif; ?></div>
        <div class="chk"><label><input type="checkbox" name="aktif" <?= (!$edit || $edit['aktif']) ? 'checked' : '' ?>> Aktif</label></div>
        <button class="btn" type="submit">Simpan</button> <?php if ($edit): ?><a class="btn btn-line" href="banner.php">Batal</a><?php endif; ?>
    </form>
</div>
<div class="box"><div class="tbl-wrap"><table class="tbl">
    <tr><th>Urut</th><th>Banner</th><th>Status</th><th>Aksi</th></tr>
    <?php foreach ($list as $b): ?>
    <tr><td><?= (int)$b['urutan'] ?></td><td><b><?= e($b['judul']) ?></b><br><small class="muted"><?= e($b['subjudul']) ?></small></td>
        <td><span class="tag <?= $b['aktif'] ? 'ok' : 'off' ?>"><?= $b['aktif'] ? 'Aktif' : 'Nonaktif' ?></span></td>
        <td style="white-space:nowrap"><a class="btn btn-sm btn-line" href="?edit=<?= $b['id'] ?>">Ubah</a>
        <form method="post" style="display:inline" data-confirm="Hapus banner ini?"><?= csrf_field() ?><input type="hidden" name="do" value="hapus"><input type="hidden" name="id" value="<?= $b['id'] ?>"><button class="btn btn-sm btn-red" type="submit">Hapus</button></form></td></tr>
    <?php endforeach; if (!$list) echo '<tr><td colspan="4" class="muted">Belum ada banner.</td></tr>'; ?>
</table></div></div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
