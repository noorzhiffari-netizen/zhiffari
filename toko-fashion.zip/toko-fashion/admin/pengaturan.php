<?php
$perm = 'pengaturan'; require __DIR__ . '/_auth.php';

$kunci = ['nama_toko', 'tagline', 'deskripsi', 'warna_utama', 'warna_aksen', 'email', 'telepon', 'whatsapp', 'alamat', 'instagram', 'facebook', 'ongkir', 'gratis_ongkir_min', 'metode_bayar', 'footer_teks'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($kunci as $k) {
        $v = trim($_POST[$k] ?? '');
        if (in_array($k, ['warna_utama', 'warna_aksen'], true) && !preg_match('/^#[0-9a-fA-F]{6}$/', $v)) continue;
        if (in_array($k, ['ongkir', 'gratis_ongkir_min'], true)) $v = (string)max(0, (int)$v);
        q('INSERT INTO pengaturan (kunci,nilai) VALUES (?,?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)', [$k, $v]);
    }
    $logo = upload_image('logo', val("SELECT nilai FROM pengaturan WHERE kunci='logo'") ?: '');
    if (isset($_POST['hapus_logo'])) { delete_image($logo); $logo = ''; }
    q("INSERT INTO pengaturan (kunci,nilai) VALUES ('logo',?) ON DUPLICATE KEY UPDATE nilai=VALUES(nilai)", [$logo]);
    flash('success', 'Pengaturan disimpan.');
    redirect('pengaturan.php');
}
$title = 'Pengaturan Toko';
require __DIR__ . '/_header.php';
$s = fn($k) => e(setting($k));
?>
<form method="post" enctype="multipart/form-data"><?= csrf_field() ?>
<div class="box"><h3>Identitas Toko</h3>
    <div class="grid2">
        <div class="form-row"><label>Nama Toko</label><input type="text" name="nama_toko" value="<?= $s('nama_toko') ?>"></div>
        <div class="form-row"><label>Tagline</label><input type="text" name="tagline" value="<?= $s('tagline') ?>"></div>
    </div>
    <div class="form-row"><label>Deskripsi singkat (footer & SEO)</label><textarea name="deskripsi" style="min-height:70px"><?= $s('deskripsi') ?></textarea></div>
    <div class="grid3">
        <div class="form-row"><label>Warna utama</label><input type="color" name="warna_utama" value="<?= $s('warna_utama') ?>"></div>
        <div class="form-row"><label>Warna aksen (tombol & harga)</label><input type="color" name="warna_aksen" value="<?= $s('warna_aksen') ?>"></div>
        <div class="form-row"><label>Logo (opsional)</label><input type="file" name="logo" accept="image/*">
            <?php if (setting('logo')): ?><img class="preview" src="<?= e(img(setting('logo'))) ?>" alt=""><br><label style="font-weight:400"><input type="checkbox" name="hapus_logo"> Hapus logo</label><?php endif; ?></div>
    </div>
</div>
<div class="box"><h3>Kontak & Sosial Media</h3>
    <div class="grid2">
        <div class="form-row"><label>Email</label><input type="text" name="email" value="<?= $s('email') ?>"></div>
        <div class="form-row"><label>Telepon</label><input type="text" name="telepon" value="<?= $s('telepon') ?>"></div>
        <div class="form-row"><label>WhatsApp (format 628xxx)</label><input type="text" name="whatsapp" value="<?= $s('whatsapp') ?>"></div>
        <div class="form-row"><label>Alamat</label><input type="text" name="alamat" value="<?= $s('alamat') ?>"></div>
        <div class="form-row"><label>Link Instagram</label><input type="text" name="instagram" value="<?= $s('instagram') ?>"></div>
        <div class="form-row"><label>Link Facebook</label><input type="text" name="facebook" value="<?= $s('facebook') ?>"></div>
    </div>
</div>
<div class="box"><h3>Pengiriman & Pembayaran</h3>
    <div class="grid2">
        <div class="form-row"><label>Ongkos kirim flat (Rp)</label><input type="number" name="ongkir" min="0" value="<?= $s('ongkir') ?>"></div>
        <div class="form-row"><label>Gratis ongkir mulai belanja (Rp, 0 = nonaktif)</label><input type="number" name="gratis_ongkir_min" min="0" value="<?= $s('gratis_ongkir_min') ?>"></div>
    </div>
    <div class="form-row"><label>Metode pembayaran (satu per baris, format: Nama|Keterangan)</label><textarea name="metode_bayar" style="min-height:120px"><?= $s('metode_bayar') ?></textarea></div>
    <div class="form-row"><label>Teks footer</label><input type="text" name="footer_teks" value="<?= $s('footer_teks') ?>"></div>
</div>
<button class="btn" type="submit">Simpan Pengaturan</button>
</form>
<?php require __DIR__ . '/_footer.php'; ?>
