<?php
$perm = 'dashboard'; require __DIR__ . '/_auth.php';
$title = 'Dashboard';
$aktif = "status IN ('diproses','dikirim','selesai')";
$s = [
    'omzet' => (float)val("SELECT COALESCE(SUM(total),0) FROM pesanan WHERE $aktif"),
    'bulan' => (float)val("SELECT COALESCE(SUM(total),0) FROM pesanan WHERE $aktif AND YEAR(created_at)=YEAR(CURDATE()) AND MONTH(created_at)=MONTH(CURDATE())"),
    'pesanan' => (int)val('SELECT COUNT(*) FROM pesanan'),
    'baru' => (int)val("SELECT COUNT(*) FROM pesanan WHERE status='menunggu_pembayaran'"),
    'produk' => (int)val('SELECT COUNT(*) FROM produk'),
    'pelanggan' => (int)val("SELECT COUNT(*) FROM users WHERE role='pelanggan'"),
];
$menipis = rows('SELECT id,nama,stok FROM produk WHERE aktif=1 AND stok<=5 ORDER BY stok ASC LIMIT 8');
$terbaru = rows('SELECT * FROM pesanan ORDER BY id DESC LIMIT 8');
require __DIR__ . '/_header.php';
?>
<div class="stats">
    <?php if (can('laporan')): ?>
    <div class="stat"><b><?= rupiah($s['omzet']) ?></b><span>Total penjualan</span></div>
    <div class="stat"><b><?= rupiah($s['bulan']) ?></b><span>Penjualan bulan ini</span></div>
    <?php endif; ?>
    <?php if (can('pesanan')): ?>
    <div class="stat"><b><?= $s['pesanan'] ?></b><span>Total pesanan (<?= $s['baru'] ?> menunggu bayar)</span></div>
    <?php endif; ?>
    <?php if (can('produk')): ?><div class="stat"><b><?= $s['produk'] ?></b><span>Produk</span></div><?php endif; ?>
    <?php if (can('pelanggan')): ?><div class="stat"><b><?= $s['pelanggan'] ?></b><span>Pelanggan</span></div><?php endif; ?>
</div>
<div class="grid2">
<?php if (can('pesanan')): ?>
<div class="box"><h3>Pesanan Terbaru</h3><div class="tbl-wrap"><table class="tbl">
    <tr><th>Kode</th><th>Pelanggan</th><th>Total</th><th>Status</th></tr>
    <?php foreach ($terbaru as $o): ?>
        <tr><td><a href="pesanan.php?id=<?= $o['id'] ?>"><b><?= e($o['kode']) ?></b></a></td><td><?= e($o['nama']) ?></td><td><?= rupiah($o['total']) ?></td><td><?= status_badge($o['status']) ?></td></tr>
    <?php endforeach; if (!$terbaru) echo '<tr><td colspan="4" class="muted">Belum ada pesanan.</td></tr>'; ?>
</table></div></div>
<?php endif; ?>
<?php if (can('produk')): ?>
<div class="box"><h3>Stok Menipis (&le; 5)</h3><div class="tbl-wrap"><table class="tbl">
    <tr><th>Produk</th><th>Stok</th><th></th></tr>
    <?php foreach ($menipis as $p): ?>
        <tr><td><?= e($p['nama']) ?></td><td><span class="tag off"><?= (int)$p['stok'] ?></span></td><td><a class="btn btn-sm btn-line" href="produk.php?edit=<?= $p['id'] ?>">Ubah</a></td></tr>
    <?php endforeach; if (!$menipis) echo '<tr><td colspan="3" class="muted">Semua stok aman.</td></tr>'; ?>
</table></div></div>
<?php endif; ?>
</div>
<?php if (!can('pesanan') && !can('produk')): ?><div class="box">Selamat datang, <?= e($me['nama']) ?>.</div><?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
