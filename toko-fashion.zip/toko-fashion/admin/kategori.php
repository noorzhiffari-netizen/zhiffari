<?php
$perm = 'kategori'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $nama = trim($_POST['nama'] ?? '');
        if ($nama === '') { flash('danger', 'Nama kategori wajib diisi.'); redirect('kategori.php'); }
        $lama = $id ? row('SELECT * FROM kategori WHERE id=?', [$id]) : null;
        $gambar = upload_image('gambar', $lama['gambar'] ?? '');
        $d = [$nama, trim($_POST['deskripsi'] ?? ''), $gambar, (int)($_POST['urutan'] ?? 0), isset($_POST['aktif']) ? 1 : 0];
        if ($lama) { q('UPDATE kategori SET nama=?,deskripsi=?,gambar=?,urutan=?,aktif=? WHERE id=?', array_merge($d, [$id])); flash('success', 'Kategori diperbarui.'); }
        else { q('INSERT INTO kategori (nama,deskripsi,gambar,urutan,aktif,slug) VALUES (?,?,?,?,?,?)', array_merge($d, [unique_slug('kategori', $nama)])); flash('success', 'Kategori ditambahkan.'); }
        redirect('kategori.php');
    }
    if ($do === 'hapus') {
        $k = row('SELECT * FROM kategori WHERE id=?', [(int)$_POST['id']]);
        if ($k) { delete_image($k['gambar']); q('DELETE FROM kategori WHERE id=?', [$k['id']]); flash('success', 'Kategori dihapus. Produk di dalamnya menjadi tanpa kategori.'); }
        redirect('kategori.php');
    }
}
$title = 'Kategori';
$edit = isset($_GET['edit']) ? row('SELECT * FROM kategori WHERE id=?', [(int)$_GET['edit']]) : null;
$list = rows('SELECT k.*, (SELECT COUNT(*) FROM produk p WHERE p.kategori_id=k.id) jml FROM kategori k ORDER BY urutan,nama');
require __DIR__ . '/_header.php';
?>
<div class="grid2" style="align-items:start">
<div class="box">
    <h3><?= $edit ? 'Ubah Kategori' : 'Tambah Kategori' ?></h3>
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="do" value="simpan"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="form-row"><label>Nama *</label><input type="text" name="nama" required value="<?= e($edit['nama'] ?? '') ?>"></div>
        <div class="form-row"><label>Deskripsi singkat</label><input type="text" name="deskripsi" value="<?= e($edit['deskripsi'] ?? '') ?>"></div>
        <div class="form-row"><label>Urutan tampil</label><input type="number" name="urutan" value="<?= (int)($edit['urutan'] ?? 0) ?>"></div>
        <div class="form-row"><label>Gambar (opsional)</label><input type="file" name="gambar" accept="image/*"><?php if (!empty($edit['gambar'])): ?><img class="preview" src="<?= e(img($edit['gambar'])) ?>" alt=""><?php endif; ?></div>
        <div class="chk"><label><input type="checkbox" name="aktif" <?= (!$edit || $edit['aktif']) ? 'checked' : '' ?>> Aktif</label></div>
        <button class="btn" type="submit">Simpan</button> <?php if ($edit): ?><a class="btn btn-line" href="kategori.php">Batal</a><?php endif; ?>
    </form>
</div>
<div class="box"><div class="tbl-wrap"><table class="tbl">
    <tr><th>Urutan</th><th>Nama</th><th>Produk</th><th>Status</th><th>Aksi</th></tr>
    <?php foreach ($list as $k): ?>
    <tr><td><?= (int)$k['urutan'] ?></td><td><b><?= e($k['nama']) ?></b><br><small class="muted"><?= e($k['slug']) ?></small></td><td><?= (int)$k['jml'] ?></td>
        <td><span class="tag <?= $k['aktif'] ? 'ok' : 'off' ?>"><?= $k['aktif'] ? 'Aktif' : 'Nonaktif' ?></span></td>
        <td style="white-space:nowrap"><a class="btn btn-sm btn-line" href="?edit=<?= $k['id'] ?>">Ubah</a>
        <form method="post" style="display:inline" data-confirm="Hapus kategori ini?"><?= csrf_field() ?><input type="hidden" name="do" value="hapus"><input type="hidden" name="id" value="<?= $k['id'] ?>"><button class="btn btn-sm btn-red" type="submit">Hapus</button></form></td></tr>
    <?php endforeach; if (!$list) echo '<tr><td colspan="5" class="muted">Belum ada kategori.</td></tr>'; ?>
</table></div></div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
