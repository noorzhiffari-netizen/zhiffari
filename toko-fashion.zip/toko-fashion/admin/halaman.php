<?php
$perm = 'halaman'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $judul = trim($_POST['judul'] ?? '');
        if ($judul === '') { flash('danger', 'Judul wajib diisi.'); redirect('halaman.php'); }
        $isi = $_POST['isi'] ?? '';
        $aktif = isset($_POST['aktif']) ? 1 : 0;
        if ($id && row('SELECT id FROM halaman WHERE id=?', [$id])) {
            q('UPDATE halaman SET judul=?,isi=?,aktif=? WHERE id=?', [$judul, $isi, $aktif, $id]);
            flash('success', 'Halaman diperbarui.');
        } else {
            q('INSERT INTO halaman (slug,judul,isi,aktif) VALUES (?,?,?,?)', [unique_slug('halaman', $judul), $judul, $isi, $aktif]);
            flash('success', 'Halaman ditambahkan.');
        }
        redirect('halaman.php');
    }
    if ($do === 'hapus') { q('DELETE FROM halaman WHERE id=?', [(int)$_POST['id']]); flash('success', 'Halaman dihapus.'); redirect('halaman.php'); }
}
$title = 'Halaman Informasi';
$edit = isset($_GET['edit']) ? row('SELECT * FROM halaman WHERE id=?', [(int)$_GET['edit']]) : null;
$list = rows('SELECT * FROM halaman ORDER BY id');
require __DIR__ . '/_header.php';
?>
<div class="grid2" style="align-items:start">
<div class="box">
    <h3><?= $edit ? 'Ubah Halaman' : 'Tambah Halaman' ?></h3>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="simpan"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="form-row"><label>Judul *</label><input type="text" name="judul" required value="<?= e($edit['judul'] ?? '') ?>"></div>
        <div class="form-row"><label>Isi (boleh memakai HTML: &lt;p&gt;, &lt;ul&gt;, &lt;b&gt;, dll.)</label><textarea name="isi" style="min-height:260px"><?= e($edit['isi'] ?? '') ?></textarea></div>
        <div class="chk"><label><input type="checkbox" name="aktif" <?= (!$edit || $edit['aktif']) ? 'checked' : '' ?>> Aktif (tampil di footer)</label></div>
        <button class="btn" type="submit">Simpan</button> <?php if ($edit): ?><a class="btn btn-line" href="halaman.php">Batal</a><?php endif; ?>
    </form>
</div>
<div class="box"><div class="tbl-wrap"><table class="tbl">
    <tr><th>Judul</th><th>Status</th><th>Aksi</th></tr>
    <?php foreach ($list as $h): ?>
    <tr><td><b><?= e($h['judul']) ?></b><br><small class="muted">halaman.php?slug=<?= e($h['slug']) ?></small></td>
        <td><span class="tag <?= $h['aktif'] ? 'ok' : 'off' ?>"><?= $h['aktif'] ? 'Aktif' : 'Nonaktif' ?></span></td>
        <td style="white-space:nowrap"><a class="btn btn-sm btn-line" href="?edit=<?= $h['id'] ?>">Ubah</a>
        <form method="post" style="display:inline" data-confirm="Hapus halaman ini?"><?= csrf_field() ?><input type="hidden" name="do" value="hapus"><input type="hidden" name="id" value="<?= $h['id'] ?>"><button class="btn btn-sm btn-red" type="submit">Hapus</button></form></td></tr>
    <?php endforeach; ?>
</table></div></div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
