<?php
$perm = 'laporan'; require __DIR__ . '/_auth.php';

$dari = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['dari'] ?? '') ? $_GET['dari'] : date('Y-m-01');
$sampai = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['sampai'] ?? '') ? $_GET['sampai'] : date('Y-m-d');
$aktif = "status IN ('diproses','dikirim','selesai') AND DATE(created_at) BETWEEN ? AND ?";
$harian = rows("SELECT DATE(created_at) tgl, COUNT(*) jml, SUM(total) omzet FROM pesanan WHERE $aktif GROUP BY DATE(created_at) ORDER BY tgl", [$dari, $sampai]);

if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="laporan-penjualan-' . $dari . '_' . $sampai . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Tanggal', 'Jumlah Pesanan', 'Omzet']);
    foreach ($harian as $h) fputcsv($out, [$h['tgl'], $h['jml'], $h['omzet']]);
    fclose($out);
    exit;
}
$top = rows("SELECT i.nama_produk, SUM(i.qty) qty, SUM(i.qty*i.harga) total FROM pesanan_item i JOIN pesanan p ON p.id=i.pesanan_id WHERE p.$aktif GROUP BY i.nama_produk ORDER BY qty DESC LIMIT 10", [$dari, $sampai]);
$totOmzet = array_sum(array_column($harian, 'omzet'));
$totJml = array_sum(array_column($harian, 'jml'));
$maxO = max(array_merge([1], array_map('floatval', array_column($harian, 'omzet'))));
$maxQ = max(array_merge([1], array_map('intval', array_column($top, 'qty'))));
$title = 'Laporan Penjualan';
require __DIR__ . '/_header.php';
?>
<div class="box noprint">
    <form method="get" class="toolbar" style="margin:0">
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
            Dari <input type="date" name="dari" value="<?= e($dari) ?>"> sampai <input type="date" name="sampai" value="<?= e($sampai) ?>">
            <button class="btn" type="submit">Tampilkan</button>
        </div>
        <div><a class="btn btn-line" href="?dari=<?= e($dari) ?>&sampai=<?= e($sampai) ?>&export=1">Unduh CSV</a> <button class="btn btn-line" type="button" onclick="window.print()">Cetak</button></div>
    </form>
</div>
<div class="stats">
    <div class="stat"><b><?= rupiah($totOmzet) ?></b><span>Omzet (pesanan diproses/dikirim/selesai)</span></div>
    <div class="stat"><b><?= (int)$totJml ?></b><span>Jumlah pesanan</span></div>
    <div class="stat"><b><?= $totJml ? rupiah($totOmzet / $totJml) : rupiah(0) ?></b><span>Rata-rata per pesanan</span></div>
</div>
<div class="grid2" style="align-items:start">
<div class="box"><h3>Penjualan Harian</h3><div class="tbl-wrap"><table class="tbl">
    <tr><th>Tanggal</th><th>Pesanan</th><th>Omzet</th><th></th></tr>
    <?php foreach ($harian as $h): ?>
    <tr><td><?= tgl($h['tgl'], false) ?></td><td><?= (int)$h['jml'] ?></td><td><?= rupiah($h['omzet']) ?></td><td style="width:30%"><div class="bar"><i style="width:<?= round($h['omzet'] / $maxO * 100) ?>%"></i></div></td></tr>
    <?php endforeach; if (!$harian) echo '<tr><td colspan="4" class="muted">Tidak ada penjualan pada periode ini.</td></tr>'; ?>
</table></div></div>
<div class="box"><h3>10 Produk Terlaris</h3><div class="tbl-wrap"><table class="tbl">
    <tr><th>Produk</th><th>Terjual</th><th>Nilai</th><th></th></tr>
    <?php foreach ($top as $t): ?>
    <tr><td><?= e($t['nama_produk']) ?></td><td><?= (int)$t['qty'] ?></td><td><?= rupiah($t['total']) ?></td><td style="width:25%"><div class="bar"><i style="width:<?= round($t['qty'] / $maxQ * 100) ?>%"></i></div></td></tr>
    <?php endforeach; if (!$top) echo '<tr><td colspan="4" class="muted">Belum ada data.</td></tr>'; ?>
</table></div></div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
