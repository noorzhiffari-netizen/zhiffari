<?php
$perm = 'pesanan'; require __DIR__ . '/_auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $o = row('SELECT * FROM pesanan WHERE id=?', [$id]);
    if ($o && ($_POST['do'] ?? '') === 'update') {
        $baru = $_POST['status'] ?? $o['status'];
        q('UPDATE pesanan SET resi=? WHERE id=?', [trim($_POST['resi'] ?? ''), $id]);
        if ($baru !== $o['status']) {
            if (ubah_status_pesanan($id, $baru)) flash('success', 'Status pesanan diperbarui.');
            else flash('danger', 'Status tidak dapat diubah (pesanan yang sudah dibatalkan tidak bisa diaktifkan lagi).');
        } else flash('success', 'Data pesanan disimpan.');
    }
    redirect('pesanan.php?id=' . $id);
}

$id = (int)($_GET['id'] ?? 0);
$title = $id ? 'Detail Pesanan' : 'Pesanan';
require __DIR__ . '/_header.php';

if ($id):
    $o = row('SELECT * FROM pesanan WHERE id=?', [$id]);
    if (!$o) { echo '<div class="alert alert-danger">Pesanan tidak ditemukan.</div>'; require __DIR__ . '/_footer.php'; exit; }
    $items = rows('SELECT * FROM pesanan_item WHERE pesanan_id=?', [$id]);
?>
<p class="noprint"><a class="btn btn-line btn-sm" href="pesanan.php">&larr; Kembali</a> <button class="btn btn-sm" onclick="window.print()">Cetak Invoice</button></p>
<div class="grid2" style="align-items:start">
<div class="box">
    <h3>Pesanan <?= e($o['kode']) ?> <?= status_badge($o['status']) ?></h3>
    <div class="tbl-wrap"><table class="tbl">
        <tr><th>Produk</th><th>Harga</th><th>Qty</th><th>Total</th></tr>
        <?php foreach ($items as $it): ?>
        <tr><td><?= e($it['nama_produk']) ?><?= $it['ukuran'] ? ' <small class="muted">(' . e($it['ukuran']) . ')</small>' : '' ?></td><td><?= rupiah($it['harga']) ?></td><td><?= (int)$it['qty'] ?></td><td><?= rupiah($it['harga'] * $it['qty']) ?></td></tr>
        <?php endforeach; ?>
        <tr><td colspan="3" align="right">Subtotal</td><td><?= rupiah($o['subtotal']) ?></td></tr>
        <tr><td colspan="3" align="right">Ongkir</td><td><?= rupiah($o['ongkir']) ?></td></tr>
        <tr><td colspan="3" align="right"><b>Total</b></td><td><b><?= rupiah($o['total']) ?></b></td></tr>
    </table></div>
</div>
<div>
    <div class="box">
        <h3>Pelanggan & Pengiriman</h3>
        <p><b><?= e($o['nama']) ?></b><br><?= e($o['telepon']) ?></p>
        <p><?= nl2br(e($o['alamat'])) ?></p>
        <p><b>Pembayaran:</b> <?= e($o['metode_bayar']) ?><br><b>Tanggal:</b> <?= tgl($o['created_at']) ?></p>
        <?php if ($o['catatan']): ?><p><b>Catatan:</b> <?= nl2br(e($o['catatan'])) ?></p><?php endif; ?>
    </div>
    <div class="box noprint">
        <h3>Ubah Status</h3>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="update"><input type="hidden" name="id" value="<?= $o['id'] ?>">
            <div class="form-row"><label>Status</label>
                <select name="status" <?= $o['status'] === 'dibatalkan' ? 'disabled' : '' ?>>
                    <?php foreach (status_list() as $k => $l): ?><option value="<?= $k ?>" <?= $o['status'] === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-row"><label>No. Resi</label><input type="text" name="resi" value="<?= e($o['resi']) ?>"></div>
            <button class="btn" type="submit">Simpan</button>
            <p class="muted"><small>Membatalkan pesanan akan mengembalikan stok produk.</small></p>
        </form>
    </div>
</div>
</div>
<?php else:
    $st = $_GET['status'] ?? ''; $cari = trim($_GET['q'] ?? ''); $page = max(1, (int)($_GET['page'] ?? 1)); $per = 15;
    $w = ['1=1']; $par = [];
    if (isset(status_list()[$st])) { $w[] = 'status=?'; $par[] = $st; }
    if ($cari !== '') { $w[] = '(kode LIKE ? OR nama LIKE ?)'; $par[] = "%$cari%"; $par[] = "%$cari%"; }
    $ws = implode(' AND ', $w);
    $total = (int)val("SELECT COUNT(*) FROM pesanan WHERE $ws", $par);
    $list = rows("SELECT * FROM pesanan WHERE $ws ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $par);
?>
<div class="box">
    <div class="toolbar"><form method="get">
        <input type="text" name="q" placeholder="Kode / nama pelanggan" value="<?= e($cari) ?>">
        <select name="status"><option value="">Semua status</option><?php foreach (status_list() as $k => $l): ?><option value="<?= $k ?>" <?= $st === $k ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select>
        <button class="btn btn-line" type="submit">Filter</button></form></div>
    <div class="tbl-wrap"><table class="tbl">
        <tr><th>Kode</th><th>Tanggal</th><th>Pelanggan</th><th>Total</th><th>Status</th><th></th></tr>
        <?php foreach ($list as $o): ?>
        <tr><td><b><?= e($o['kode']) ?></b></td><td><?= tgl($o['created_at']) ?></td><td><?= e($o['nama']) ?></td><td><?= rupiah($o['total']) ?></td><td><?= status_badge($o['status']) ?></td><td><a class="btn btn-sm" href="?id=<?= $o['id'] ?>">Detail</a></td></tr>
        <?php endforeach; if (!$list) echo '<tr><td colspan="6" class="muted">Tidak ada pesanan.</td></tr>'; ?>
    </table></div>
    <?= pager($total, $per, $page) ?>
</div>
<?php endif; require __DIR__ . '/_footer.php'; ?>
