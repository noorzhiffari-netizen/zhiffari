<?php
$me = current_user();
require __DIR__ . '/_header.php';
?>
<div class="box" style="text-align:center;padding:50px 20px">
    <div style="font-size:3rem">&#128274;</div>
    <h2>Akses Ditolak</h2>
    <p>Peran Anda (<b><?= e(role_label($me['role'])) ?></b>) tidak memiliki izin untuk membuka halaman ini.</p>
    <a class="btn" href="index.php">Kembali ke Dashboard</a>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
