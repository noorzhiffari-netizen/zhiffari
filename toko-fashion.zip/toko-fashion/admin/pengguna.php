<?php
$perm = 'pengguna'; require __DIR__ . '/_auth.php'; // hanya Super Admin

$roles = ['super_admin', 'admin', 'staf_produk', 'staf_pesanan'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $do = $_POST['do'] ?? '';
    if ($do === 'simpan') {
        $id = (int)($_POST['id'] ?? 0);
        $nama = trim($_POST['nama'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $role = $_POST['role'] ?? '';
        $pw = $_POST['password'] ?? '';
        $aktif = isset($_POST['aktif']) ? 1 : 0;
        $lama = $id ? row('SELECT * FROM users WHERE id=?', [$id]) : null;
        $err = '';
        if ($nama === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $err = 'Nama dan email yang valid wajib diisi.';
        elseif (!in_array($role, $roles, true)) $err = 'Peran tidak valid.';
        elseif (val('SELECT COUNT(*) FROM users WHERE email=? AND id<>?', [$email, $id])) $err = 'Email sudah dipakai.';
        elseif (!$lama && strlen($pw) < 6) $err = 'Password minimal 6 karakter.';
        elseif ($lama && $pw !== '' && strlen($pw) < 6) $err = 'Password baru minimal 6 karakter.';
        elseif ($lama && $lama['id'] == $me['id'] && ($role !== $lama['role'] || !$aktif)) $err = 'Anda tidak dapat mengubah peran atau menonaktifkan akun Anda sendiri.';
        if ($err) { flash('danger', $err); redirect('pengguna.php' . ($id ? '?edit=' . $id : '')); }
        if ($lama) {
            q('UPDATE users SET nama=?,email=?,telepon=?,role=?,aktif=? WHERE id=?', [$nama, $email, trim($_POST['telepon'] ?? ''), $role, $aktif, $id]);
            if ($pw !== '') q('UPDATE users SET password=? WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $id]);
            flash('success', 'Pengelola diperbarui.');
        } else {
            q('INSERT INTO users (nama,email,password,telepon,role,aktif) VALUES (?,?,?,?,?,?)', [$nama, $email, password_hash($pw, PASSWORD_DEFAULT), trim($_POST['telepon'] ?? ''), $role, $aktif]);
            flash('success', 'Pengelola ditambahkan.');
        }
        redirect('pengguna.php');
    }
    if ($do === 'hapus') {
        $id = (int)$_POST['id'];
        if ($id === (int)$me['id']) flash('danger', 'Anda tidak dapat menghapus akun sendiri.');
        else { q("DELETE FROM users WHERE id=? AND role<>'pelanggan'", [$id]); flash('success', 'Pengelola dihapus.'); }
        redirect('pengguna.php');
    }
}
$title = 'Pengelola Website';
$edit = isset($_GET['edit']) ? row("SELECT * FROM users WHERE id=? AND role<>'pelanggan'", [(int)$_GET['edit']]) : null;
$list = rows("SELECT * FROM users WHERE role<>'pelanggan' ORDER BY FIELD(role,'super_admin','admin','staf_produk','staf_pesanan'), nama");
require __DIR__ . '/_header.php';
?>
<div class="box">
    <h3>Hak Akses Peran</h3>
    <div class="tbl-wrap"><table class="tbl">
        <tr><th>Peran</th><th>Hak akses</th></tr>
        <tr><td><b>Super Admin</b></td><td>Semua fitur, termasuk mengelola pengelola, pengaturan toko, dan semua data.</td></tr>
        <tr><td><b>Admin Toko</b></td><td>Produk, kategori, pesanan, pelanggan, banner, halaman, laporan, pengaturan toko.</td></tr>
        <tr><td><b>Staf Produk</b></td><td>Produk, kategori, dan banner beranda.</td></tr>
        <tr><td><b>Staf Pesanan</b></td><td>Pesanan (ubah status & resi), pelanggan, dan laporan penjualan.</td></tr>
    </table></div>
</div>
<div class="grid2" style="align-items:start">
<div class="box">
    <h3><?= $edit ? 'Ubah Pengelola' : 'Tambah Pengelola' ?></h3>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="simpan"><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
        <div class="form-row"><label>Nama *</label><input type="text" name="nama" required value="<?= e($edit['nama'] ?? '') ?>"></div>
        <div class="form-row"><label>Email *</label><input type="email" name="email" required value="<?= e($edit['email'] ?? '') ?>"></div>
        <div class="form-row"><label>Telepon</label><input type="tel" name="telepon" value="<?= e($edit['telepon'] ?? '') ?>"></div>
        <div class="form-row"><label>Peran *</label><select name="role"><?php foreach ($roles as $r): ?><option value="<?= $r ?>" <?= ($edit['role'] ?? 'staf_produk') === $r ? 'selected' : '' ?>><?= e(role_label($r)) ?></option><?php endforeach; ?></select></div>
        <div class="form-row"><label>Password <?= $edit ? '(kosongkan jika tidak diubah)' : '*' ?></label><input type="password" name="password" minlength="6" <?= $edit ? '' : 'required' ?>></div>
        <div class="chk"><label><input type="checkbox" name="aktif" <?= (!$edit || $edit['aktif']) ? 'checked' : '' ?>> Akun aktif</label></div>
        <button class="btn" type="submit">Simpan</button> <?php if ($edit): ?><a class="btn btn-line" href="pengguna.php">Batal</a><?php endif; ?>
    </form>
</div>
<div class="box"><div class="tbl-wrap"><table class="tbl">
    <tr><th>Nama</th><th>Peran</th><th>Status</th><th>Aksi</th></tr>
    <?php foreach ($list as $u): ?>
    <tr><td><b><?= e($u['nama']) ?></b><br><small class="muted"><?= e($u['email']) ?></small></td><td><?= e(role_label($u['role'])) ?></td>
        <td><span class="tag <?= $u['aktif'] ? 'ok' : 'off' ?>"><?= $u['aktif'] ? 'Aktif' : 'Nonaktif' ?></span></td>
        <td style="white-space:nowrap"><a class="btn btn-sm btn-line" href="?edit=<?= $u['id'] ?>">Ubah</a>
        <?php if ($u['id'] != $me['id']): ?><form method="post" style="display:inline" data-confirm="Hapus pengelola ini?"><?= csrf_field() ?><input type="hidden" name="do" value="hapus"><input type="hidden" name="id" value="<?= $u['id'] ?>"><button class="btn btn-sm btn-red" type="submit">Hapus</button></form><?php endif; ?></td></tr>
    <?php endforeach; ?>
</table></div></div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
