<?php
$menu = [
    ['index.php', 'Dashboard', 'dashboard', '&#9638;'],
    ['produk.php', 'Produk', 'produk', '&#128085;'],
    ['kategori.php', 'Kategori', 'kategori', '&#128193;'],
    ['pesanan.php', 'Pesanan', 'pesanan', '&#128717;'],
    ['pelanggan.php', 'Pelanggan', 'pelanggan', '&#128101;'],
    ['banner.php', 'Banner', 'banner', '&#127912;'],
    ['halaman.php', 'Halaman', 'halaman', '&#128196;'],
    ['laporan.php', 'Laporan', 'laporan', '&#128200;'],
    ['pengguna.php', 'Pengelola', 'pengguna', '&#128273;'],
    ['pengaturan.php', 'Pengaturan', 'pengaturan', '&#9881;'],
];
$cur = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'Admin') ?> | Admin <?= e(setting('nama_toko')) ?></title>
<link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>">
</head>
<body>
<button class="burger" onclick="document.body.classList.toggle('side-open')">&#9776;</button>
<aside class="side">
    <div class="brand"><?= e(setting('nama_toko')) ?><small>Panel Admin</small></div>
    <nav>
        <?php foreach ($menu as $m): if (!can($m[2])) continue; ?>
            <a href="<?= $m[0] ?>" class="<?= $cur === $m[0] ? 'on' : '' ?>"><span><?= $m[3] ?></span> <?= $m[1] ?></a>
        <?php endforeach; ?>
        <a href="profil.php" class="<?= $cur === 'profil.php' ? 'on' : '' ?>"><span>&#128100;</span> Profil Saya</a>
        <a href="<?= url('index.php') ?>" target="_blank"><span>&#127760;</span> Lihat Toko</a>
        <a href="logout.php"><span>&#10162;</span> Keluar</a>
    </nav>
</aside>
<div class="main">
    <div class="topline">
        <h1><?= e($title ?? 'Admin') ?></h1>
        <div class="who"><?= e($me['nama']) ?> <span class="role"><?= e(role_label($me['role'])) ?></span></div>
    </div>
    <?php render_flash(); ?>
