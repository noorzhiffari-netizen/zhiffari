<?php
require_once __DIR__ . '/../includes/init.php';
$u = current_user();
if ($u && $u['role'] !== 'pelanggan') redirect('index.php');
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = row('SELECT * FROM users WHERE email=? AND aktif=1 AND role<>?', [strtolower(trim($_POST['email'] ?? '')), 'pelanggan']);
    if ($user && password_verify($_POST['password'] ?? '', $user['password'])) { login_user($user); redirect('index.php'); }
    $err = 'Email/password salah, atau akun Anda bukan pengelola.';
}
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Admin | <?= e(setting('nama_toko')) ?></title>
<link rel="stylesheet" href="<?= url('assets/css/admin.css') ?>"></head>
<body>
<div class="login-wrap"><div class="login-box">
    <h2 style="margin-top:0">Login Pengelola</h2>
    <p class="muted"><?= e(setting('nama_toko')) ?></p>
    <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
    <form method="post"><?= csrf_field() ?>
        <div class="form-row"><label>Email</label><input type="email" name="email" required autofocus></div>
        <div class="form-row"><label>Password</label><input type="password" name="password" required></div>
        <button class="btn" style="width:100%" type="submit">Masuk</button>
    </form>
    <p style="text-align:center"><a href="<?= url('index.php') ?>">&larr; Kembali ke toko</a></p>
</div></div>
</body></html>
