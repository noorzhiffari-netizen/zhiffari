<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Semua Produk';
$kat = trim($_GET['kategori'] ?? '');
$cari = trim($_GET['q'] ?? '');
$sort = $_GET['sort'] ?? 'terbaru';
$min = (int)($_GET['min'] ?? 0);
$max = (int)($_GET['max'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 12;

$where = ['p.aktif=1']; $par = [];
if ($kat !== '') {
    $k = row('SELECT * FROM kategori WHERE slug=? AND aktif=1', [$kat]);
    if ($k) { $where[] = 'p.kategori_id=?'; $par[] = $k['id']; $pageTitle = $k['nama']; }
}
if ($cari !== '') { $where[] = '(p.nama LIKE ? OR p.deskripsi LIKE ?)'; $par[] = "%$cari%"; $par[] = "%$cari%"; $pageTitle = 'Cari: ' . $cari; }
if ($min > 0) { $where[] = 'IF(p.harga_diskon>0 AND p.harga_diskon<p.harga,p.harga_diskon,p.harga)>=?'; $par[] = $min; }
if ($max > 0) { $where[] = 'IF(p.harga_diskon>0 AND p.harga_diskon<p.harga,p.harga_diskon,p.harga)<=?'; $par[] = $max; }
if ($sort === 'diskon') $where[] = 'p.harga_diskon>0 AND p.harga_diskon<p.harga';

$order = [
    'terbaru' => 'p.id DESC',
    'termurah' => 'IF(p.harga_diskon>0 AND p.harga_diskon<p.harga,p.harga_diskon,p.harga) ASC',
    'termahal' => 'IF(p.harga_diskon>0 AND p.harga_diskon<p.harga,p.harga_diskon,p.harga) DESC',
    'terlaris' => 'p.terjual DESC',
    'diskon' => '(p.harga-p.harga_diskon)/p.harga DESC',
][$sort] ?? 'p.id DESC';

$w = implode(' AND ', $where);
$total = (int)val("SELECT COUNT(*) FROM produk p WHERE $w", $par);
$off = ($page - 1) * $per;
$list = rows("SELECT p.* FROM produk p WHERE $w ORDER BY $order LIMIT " . (int)$per . " OFFSET " . (int)$off, $par);
$cats = rows('SELECT * FROM kategori WHERE aktif=1 ORDER BY urutan,nama');
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<div class="listing">
    <aside class="filter">
        <h4>Kategori</h4>
        <ul>
            <li><a class="<?= $kat === '' ? 'on' : '' ?>" href="<?= url('produk.php') ?>">Semua</a></li>
            <?php foreach ($cats as $c): ?>
                <li><a class="<?= $kat === $c['slug'] ? 'on' : '' ?>" href="<?= url('produk.php?kategori=' . urlencode($c['slug'])) ?>"><?= e($c['nama']) ?></a></li>
            <?php endforeach; ?>
        </ul>
        <form method="get">
            <?php if ($kat !== ''): ?><input type="hidden" name="kategori" value="<?= e($kat) ?>"><?php endif; ?>
            <?php if ($cari !== ''): ?><input type="hidden" name="q" value="<?= e($cari) ?>"><?php endif; ?>
            <input type="hidden" name="sort" value="<?= e($sort) ?>">
            <h4>Rentang Harga</h4>
            <input type="number" name="min" placeholder="Harga minimum" value="<?= $min ?: '' ?>" min="0">
            <input type="number" name="max" placeholder="Harga maksimum" value="<?= $max ?: '' ?>" min="0">
            <button class="btn btn-block btn-sm" type="submit">Terapkan</button>
        </form>
    </aside>
    <div>
        <div class="toolbar">
            <div><h2 style="margin:0"><?= e($pageTitle) ?></h2><small class="muted"><?= $total ?> produk ditemukan</small></div>
            <form method="get">
                <?php foreach (['kategori' => $kat, 'q' => $cari] as $k2 => $v2) if ($v2 !== '') echo '<input type="hidden" name="' . $k2 . '" value="' . e($v2) . '">'; ?>
                <select name="sort" onchange="this.form.submit()">
                    <?php foreach (['terbaru' => 'Terbaru', 'terlaris' => 'Terlaris', 'termurah' => 'Harga Terendah', 'termahal' => 'Harga Tertinggi', 'diskon' => 'Diskon Terbesar'] as $v => $l): ?>
                        <option value="<?= $v ?>" <?= $sort === $v ? 'selected' : '' ?>><?= $l ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
        <?php if ($list): ?>
            <div class="grid"><?php foreach ($list as $p) echo product_card($p); ?></div>
            <?= pager($total, $per, $page) ?>
        <?php else: ?>
            <div class="panel">Produk tidak ditemukan. Coba ubah kata kunci atau filter.</div>
        <?php endif; ?>
    </div>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
