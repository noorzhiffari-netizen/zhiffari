<?php
require_once __DIR__ . '/includes/init.php';
$items = cart_items();
if (!$items) { flash('info', 'Keranjang Anda kosong.'); redirect(url('keranjang.php')); }
$u = current_user();
if (!$u) {
    $_SESSION['after_login'] = url('checkout.php');
    flash('info', 'Silakan masuk atau daftar untuk melanjutkan checkout.');
    redirect(url('login.php'));
}
$sub = cart_subtotal($items);
$ongkir = hitung_ongkir($sub);
$metode = metode_bayar_list();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $telp = trim($_POST['telepon'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $bayar = trim($_POST['metode'] ?? '');
    $catatan = trim($_POST['catatan'] ?? '');
    $namaMetode = array_column($metode, 'nama');
    if ($nama === '' || $telp === '' || $alamat === '') $err = 'Nama, telepon, dan alamat wajib diisi.';
    elseif (!in_array($bayar, $namaMetode, true)) $err = 'Pilih metode pembayaran.';
    else {
        db()->beginTransaction();
        try {
            $kode = 'TF' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
            q('INSERT INTO pesanan (kode,user_id,nama,telepon,alamat,metode_bayar,subtotal,ongkir,total,catatan) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [$kode, $u['id'], $nama, $telp, $alamat, $bayar, $sub, $ongkir, $sub + $ongkir, $catatan]);
            $pid = db()->lastInsertId();
            foreach ($items as $it) {
                $st = q('UPDATE produk SET stok=stok-?, terjual=terjual+? WHERE id=? AND stok>=? AND aktif=1', [$it['qty'], $it['qty'], $it['p']['id'], $it['qty']]);
                if ($st->rowCount() < 1) throw new Exception('Stok "' . $it['p']['nama'] . '" tidak mencukupi.');
                q('INSERT INTO pesanan_item (pesanan_id,produk_id,nama_produk,harga,ukuran,qty) VALUES (?,?,?,?,?,?)',
                    [$pid, $it['p']['id'], $it['p']['nama'], $it['harga'], $it['ukuran'], $it['qty']]);
            }
            db()->commit();
            unset($_SESSION['cart']);
            redirect(url('pesanan_sukses.php?kode=' . urlencode($kode)));
        } catch (Exception $ex) {
            if (db()->inTransaction()) db()->rollBack();
            $err = $ex->getMessage() ?: 'Terjadi kesalahan saat memproses pesanan.';
        }
    }
}

$pageTitle = 'Checkout';
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<h1 class="page-title">Checkout</h1>
<?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="two">
    <?= csrf_field() ?>
    <div>
        <div class="panel">
            <h3>Data Pengiriman</h3>
            <div class="form-row"><label>Nama Penerima</label><input type="text" name="nama" required value="<?= e($_POST['nama'] ?? $u['nama']) ?>"></div>
            <div class="form-row"><label>No. Telepon / WhatsApp</label><input type="tel" name="telepon" required value="<?= e($_POST['telepon'] ?? $u['telepon']) ?>"></div>
            <div class="form-row"><label>Alamat Lengkap</label><textarea name="alamat" required><?= e($_POST['alamat'] ?? $u['alamat']) ?></textarea></div>
            <div class="form-row"><label>Catatan (opsional)</label><textarea name="catatan" style="min-height:60px"><?= e($_POST['catatan'] ?? '') ?></textarea></div>
        </div>
        <div class="panel">
            <h3>Metode Pembayaran</h3>
            <?php foreach ($metode as $m): ?>
                <label class="pay"><input type="radio" name="metode" value="<?= e($m['nama']) ?>" required <?= (($_POST['metode'] ?? '') === $m['nama']) ? 'checked' : '' ?>> <b><?= e($m['nama']) ?></b><small><?= e($m['ket']) ?></small></label>
            <?php endforeach; ?>
            <?php if (!$metode): ?><p class="muted">Metode pembayaran belum diatur oleh admin.</p><?php endif; ?>
        </div>
    </div>
    <div class="panel">
        <h3>Pesanan Anda</h3>
        <?php foreach ($items as $it): ?>
            <div class="sum-row"><span><?= e($it['p']['nama']) ?><?= $it['ukuran'] ? ' (' . e($it['ukuran']) . ')' : '' ?> &times; <?= $it['qty'] ?></span><span><?= rupiah($it['total']) ?></span></div>
        <?php endforeach; ?>
        <div class="sum-row" style="border-top:1px solid #eee;margin-top:6px"><span>Subtotal</span><span><?= rupiah($sub) ?></span></div>
        <div class="sum-row"><span>Ongkos kirim</span><span><?= $ongkir > 0 ? rupiah($ongkir) : 'GRATIS' ?></span></div>
        <div class="sum-row total"><span>Total</span><span><?= rupiah($sub + $ongkir) ?></span></div>
        <button class="btn btn-accent btn-block" style="margin-top:14px" type="submit">Buat Pesanan</button>
    </div>
</form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
