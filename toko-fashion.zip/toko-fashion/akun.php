<?php
require_once __DIR__ . '/includes/init.php';
$u = current_user();
if (!$u) { $_SESSION['after_login'] = url('akun.php'); redirect(url('login.php')); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    if ($aksi === 'profil') {
        $nama = trim($_POST['nama'] ?? '');
        if ($nama === '') flash('danger', 'Nama wajib diisi.');
        else {
            q('UPDATE users SET nama=?, telepon=?, alamat=? WHERE id=?', [$nama, trim($_POST['telepon'] ?? ''), trim($_POST['alamat'] ?? ''), $u['id']]);
            flash('success', 'Profil diperbarui.');
        }
    }
    if ($aksi === 'password') {
        $baru = $_POST['baru'] ?? '';
        if (!password_verify($_POST['lama'] ?? '', $u['password'])) flash('danger', 'Password lama salah.');
        elseif (strlen($baru) < 6) flash('danger', 'Password baru minimal 6 karakter.');
        elseif ($baru !== ($_POST['baru2'] ?? '')) flash('danger', 'Konfirmasi password tidak sama.');
        else { q('UPDATE users SET password=? WHERE id=?', [password_hash($baru, PASSWORD_DEFAULT), $u['id']]); flash('success', 'Password berhasil diubah.'); }
    }
    redirect(url('akun.php'));
}

$orders = rows('SELECT * FROM pesanan WHERE user_id=? ORDER BY id DESC', [$u['id']]);
$pageTitle = 'Akun Saya';
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<h1 class="page-title">Akun Saya</h1>
<div class="two">
    <div class="panel">
        <h3>Riwayat Pesanan</h3>
        <?php if (!$orders): ?><p class="muted">Belum ada pesanan.</p><?php else: ?>
        <table class="tbl resp">
            <thead><tr><th>Kode</th><th>Tanggal</th><th>Total</th><th>Status</th><th></th></tr></thead>
            <?php foreach ($orders as $o): ?>
                <tr><td><b><?= e($o['kode']) ?></b></td><td><?= tgl($o['created_at']) ?></td><td><?= rupiah($o['total']) ?></td><td><?= status_badge($o['status']) ?></td>
                <td><a class="btn btn-sm" href="<?= url('pesanan.php?kode=' . urlencode($o['kode'])) ?>">Detail</a></td></tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </div>
    <div>
        <div class="panel">
            <h3>Profil</h3>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="profil">
                <div class="form-row"><label>Nama</label><input type="text" name="nama" required value="<?= e($u['nama']) ?>"></div>
                <div class="form-row"><label>Email</label><input type="email" value="<?= e($u['email']) ?>" disabled></div>
                <div class="form-row"><label>Telepon</label><input type="tel" name="telepon" value="<?= e($u['telepon']) ?>"></div>
                <div class="form-row"><label>Alamat</label><textarea name="alamat"><?= e($u['alamat']) ?></textarea></div>
                <button class="btn btn-block" type="submit">Simpan</button>
            </form>
        </div>
        <div class="panel">
            <h3>Ganti Password</h3>
            <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="password">
                <div class="form-row"><label>Password Lama</label><input type="password" name="lama" required></div>
                <div class="form-row"><label>Password Baru</label><input type="password" name="baru" required minlength="6"></div>
                <div class="form-row"><label>Ulangi Password Baru</label><input type="password" name="baru2" required minlength="6"></div>
                <button class="btn btn-block" type="submit">Ubah Password</button>
            </form>
        </div>
    </div>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
