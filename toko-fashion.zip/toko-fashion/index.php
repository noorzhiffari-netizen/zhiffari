<?php
require_once __DIR__ . '/includes/init.php';
$pageTitle = 'Beranda';
$banners = rows('SELECT * FROM banner WHERE aktif=1 ORDER BY urutan,id');
$cats = rows('SELECT k.*, (SELECT COUNT(*) FROM produk p WHERE p.kategori_id=k.id AND p.aktif=1) jml FROM kategori k WHERE aktif=1 ORDER BY urutan,nama');
$unggulan = rows('SELECT * FROM produk WHERE aktif=1 AND unggulan=1 ORDER BY id DESC LIMIT 8');
$terbaru = rows('SELECT * FROM produk WHERE aktif=1 ORDER BY id DESC LIMIT 8');
$diskon = rows('SELECT * FROM produk WHERE aktif=1 AND harga_diskon>0 AND harga_diskon<harga ORDER BY (harga-harga_diskon)/harga DESC LIMIT 4');
require __DIR__ . '/includes/header.php';
?>
<?php if ($banners): ?>
<div class="hero">
    <?php foreach ($banners as $b):
        $has = $b['gambar'] && is_file(UPLOAD_DIR . $b['gambar']); ?>
        <div class="slide <?= $has ? '' : 'nobg' ?>" <?= $has ? 'style="background-image:url(\'' . e(img($b['gambar'])) . '\')"' : '' ?>>
            <div class="shade"><div class="container">
                <h1><?= e($b['judul']) ?></h1>
                <p><?= e($b['subjudul']) ?></p>
                <?php if ($b['link']): ?><a class="btn btn-accent" href="<?= e(preg_match('#^https?://#', $b['link']) ? $b['link'] : url($b['link'])) ?>"><?= e($b['tombol'] ?: 'Lihat') ?></a><?php endif; ?>
            </div></div>
        </div>
    <?php endforeach; ?>
    <?php if (count($banners) > 1): ?>
    <div class="dots"><?php foreach ($banners as $b): ?><button aria-label="slide"></button><?php endforeach; ?></div>
    <?php endif; ?>
</div>
<?php endif; ?>

<section class="blok"><div class="container">
    <div class="sec-head"><h2>Belanja per Kategori</h2></div>
    <div class="cats">
        <?php foreach ($cats as $c): ?>
            <a class="cat" href="<?= url('produk.php?kategori=' . urlencode($c['slug'])) ?>"><?= e($c['nama']) ?><small><?= (int)$c['jml'] ?> produk</small></a>
        <?php endforeach; ?>
    </div>
</div></section>

<?php if ($diskon): ?>
<section class="blok"><div class="container">
    <div class="sec-head"><h2>Promo Diskon</h2><a href="<?= url('produk.php?sort=diskon') ?>">Lihat semua &rarr;</a></div>
    <div class="grid"><?php foreach ($diskon as $p) echo product_card($p); ?></div>
</div></section>
<?php endif; ?>

<?php if ($unggulan): ?>
<section class="blok"><div class="container">
    <div class="sec-head"><h2>Produk Unggulan</h2><a href="<?= url('produk.php') ?>">Lihat semua &rarr;</a></div>
    <div class="grid"><?php foreach ($unggulan as $p) echo product_card($p); ?></div>
</div></section>
<?php endif; ?>

<section class="blok"><div class="container">
    <div class="sec-head"><h2>Terbaru</h2><a href="<?= url('produk.php?sort=terbaru') ?>">Lihat semua &rarr;</a></div>
    <div class="grid"><?php foreach ($terbaru as $p) echo product_card($p); ?></div>
    <?php if (!$terbaru): ?><p class="muted">Belum ada produk. Tambahkan produk lewat halaman admin.</p><?php endif; ?>
</div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
