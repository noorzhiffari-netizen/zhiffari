# Toko Fashion Online (PHP + MySQL)

Toko online fashion berbasis web: pakaian, sepatu, tas, aksesoris, hijab & busana muslim.
Seluruh isi toko (produk, kategori, banner, halaman, warna, kontak, ongkir, metode bayar) dapat diubah dari halaman admin.

## Cara Pasang
1. Salin folder `toko-fashion` ke `htdocs` (XAMPP) atau `www` (Laragon/WAMP) atau `public_html` (hosting).
2. Buka phpMyAdmin -> tab **Import** -> pilih `database.sql` -> **Go**
   (otomatis membuat database `toko_fashion` + data contoh).
3. Sesuaikan `config.php` bila user/password MySQL berbeda (default: root, tanpa password).
4. Pastikan folder `uploads/` dapat ditulis (chmod 755/775 di hosting Linux).
5. Buka `http://localhost/toko-fashion/` (toko) dan `http://localhost/toko-fashion/admin/` (admin).

Kebutuhan: PHP 7.4+ (disarankan 8.x) dengan ekstensi PDO MySQL, MySQL/MariaDB 5.7+.

## Akun Contoh (password semua: `password`) - WAJIB DIGANTI
| Peran | Email |
|---|---|
| Super Admin | admin@tokofashion.test |
| Admin Toko | manajer@tokofashion.test |
| Staf Produk | produk@tokofashion.test |
| Staf Pesanan | pesanan@tokofashion.test |
| Pelanggan | pelanggan@tokofashion.test |

Ganti password di menu **Profil Saya**; kelola akun pengelola di menu **Pengelola** (Super Admin).

## Hak Akses Peran
| Menu | Super Admin | Admin Toko | Staf Produk | Staf Pesanan |
|---|:-:|:-:|:-:|:-:|
| Dashboard | v | v | v | v |
| Produk & Kategori | v | v | v | - |
| Banner | v | v | v | - |
| Pesanan | v | v | - | v |
| Pelanggan | v | v | - | v |
| Laporan | v | v | - | v |
| Halaman Informasi | v | v | - | - |
| Pengaturan Toko | v | v | - | - |
| Pengelola (user) | v | - | - | - |

Aturan akses ada di `includes/functions.php` (fungsi `role_perms()`).

## Fitur Toko
- Beranda: slider banner, kategori, promo, unggulan, terbaru
- Katalog: cari, filter kategori & harga, urutkan, pagination
- Detail produk: pilih ukuran, jumlah, beli sekarang
- Keranjang, checkout (wajib login), ongkir flat + gratis ongkir minimum, stok otomatis berkurang
- Akun pelanggan: riwayat pesanan, batalkan pesanan, ubah profil/password
- Admin: CRUD produk/kategori/banner/halaman, kelola pesanan (status, resi, invoice cetak), laporan + CSV, pengaturan

## Keamanan
PDO prepared statement, password_hash, token CSRF di semua form, validasi upload gambar, folder `uploads/` tanpa eksekusi PHP.
Sebelum online: ganti semua password contoh, gunakan HTTPS, dan buat user MySQL khusus (jangan root).
