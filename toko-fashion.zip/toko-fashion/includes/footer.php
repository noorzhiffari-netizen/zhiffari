</main>
<footer class="site">
    <div class="container">
        <div class="foot-grid">
            <div>
                <h4><?= e(setting('nama_toko')) ?></h4>
                <p><?= e(setting('deskripsi')) ?></p>
                <p>
                    <?php if (setting('instagram')): ?><a href="<?= e(setting('instagram')) ?>" target="_blank" rel="noopener">Instagram</a> &nbsp;<?php endif; ?>
                    <?php if (setting('facebook')): ?><a href="<?= e(setting('facebook')) ?>" target="_blank" rel="noopener">Facebook</a><?php endif; ?>
                </p>
            </div>
            <div>
                <h4>Kategori</h4>
                <ul>
                    <?php foreach ($cats as $c): ?>
                        <li><a href="<?= url('produk.php?kategori=' . urlencode($c['slug'])) ?>"><?= e($c['nama']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div>
                <h4>Informasi</h4>
                <ul>
                    <?php foreach ($halamanMenu as $h): ?>
                        <li><a href="<?= url('halaman.php?slug=' . urlencode($h['slug'])) ?>"><?= e($h['judul']) ?></a></li>
                    <?php endforeach; ?>
                    <li><a href="<?= url('akun.php') ?>">Pesanan Saya</a></li>
                </ul>
            </div>
            <div>
                <h4>Kontak</h4>
                <ul>
                    <li><?= e(setting('alamat')) ?></li>
                    <li>Telp: <?= e(setting('telepon')) ?></li>
                    <li><?= e(setting('email')) ?></li>
                </ul>
            </div>
        </div>
        <div class="copy">&copy; <?= date('Y') ?> <?= e(setting('nama_toko')) ?>. <?= e(setting('footer_teks')) ?></div>
    </div>
</footer>
<?php if (setting('whatsapp')): ?>
<a class="wa-float" target="_blank" rel="noopener" href="https://wa.me/<?= e(preg_replace('/\D/', '', setting('whatsapp'))) ?>" title="Chat WhatsApp">&#128172;</a>
<?php endif; ?>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
