<?php
require_once __DIR__ . '/init.php';
$pageTitle = $pageTitle ?? setting('nama_toko');
$cats = rows('SELECT * FROM kategori WHERE aktif=1 ORDER BY urutan,nama');
$halamanMenu = rows('SELECT slug,judul FROM halaman WHERE aktif=1 ORDER BY id');
$cu = current_user();
$curKat = $_GET['kategori'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> | <?= e(setting('nama_toko')) ?></title>
<meta name="description" content="<?= e(setting('deskripsi')) ?>">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
<style>:root{--primary:<?= e(setting('warna_utama', '#111827')) ?>;--accent:<?= e(setting('warna_aksen', '#e11d48')) ?>}</style>
</head>
<body>
<div class="topbar">
    <?php $min = (float)setting('gratis_ongkir_min', 0); ?>
    <?= $min > 0 ? 'Gratis ongkir untuk pembelian min. ' . rupiah($min) . ' &bull; ' : '' ?><?= e(setting('tagline')) ?>
</div>
<header class="site">
    <div class="container head-row">
        <button class="menu-toggle" aria-label="Menu">&#9776;</button>
        <a class="logo" href="<?= url('index.php') ?>">
            <?php if (setting('logo') && is_file(UPLOAD_DIR . setting('logo'))): ?>
                <img src="<?= e(img(setting('logo'))) ?>" alt="<?= e(setting('nama_toko')) ?>">
            <?php else: ?><?= e(setting('nama_toko')) ?><?php endif; ?>
        </a>
        <form class="search" action="<?= url('produk.php') ?>" method="get">
            <input type="text" name="q" placeholder="Cari produk fashion..." value="<?= e($_GET['q'] ?? '') ?>">
            <button type="submit">Cari</button>
        </form>
        <div class="head-actions">
            <?php if ($cu): ?>
                <a href="<?= url('akun.php') ?>">Hai, <?= e(explode(' ', $cu['nama'])[0]) ?></a>
                <?php if ($cu['role'] !== 'pelanggan'): ?><a class="hide-m" href="<?= url('admin/index.php') ?>">Admin</a><?php endif; ?>
                <a class="hide-m" href="<?= url('logout.php') ?>">Keluar</a>
            <?php else: ?>
                <a href="<?= url('login.php') ?>">Masuk</a>
                <a class="hide-m" href="<?= url('register.php') ?>">Daftar</a>
            <?php endif; ?>
            <a class="cart-link" href="<?= url('keranjang.php') ?>">Keranjang<span class="count"><?= cart_count() ?></span></a>
        </div>
    </div>
    <nav class="main">
        <div class="container">
            <ul>
                <li><a href="<?= url('index.php') ?>">Beranda</a></li>
                <li><a href="<?= url('produk.php') ?>" class="<?= ($curKat === '' && basename($_SERVER['SCRIPT_NAME']) === 'produk.php') ? 'on' : '' ?>">Semua Produk</a></li>
                <?php foreach ($cats as $c): ?>
                    <li><a class="<?= $curKat === $c['slug'] ? 'on' : '' ?>" href="<?= url('produk.php?kategori=' . urlencode($c['slug'])) ?>"><?= e($c['nama']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </nav>
</header>
<main>
<div class="container"><?php render_flash(); ?></div>
