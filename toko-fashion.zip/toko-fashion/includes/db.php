<?php
function db() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER, DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            die('Koneksi database gagal. Pastikan database sudah diimpor dan config.php sudah benar.');
        }
    }
    return $pdo;
}
function q($sql, $p = []) { $s = db()->prepare($sql); $s->execute($p); return $s; }
function row($sql, $p = []) { return q($sql, $p)->fetch(); }
function rows($sql, $p = []) { return q($sql, $p)->fetchAll(); }
function val($sql, $p = []) { return q($sql, $p)->fetchColumn(); }
