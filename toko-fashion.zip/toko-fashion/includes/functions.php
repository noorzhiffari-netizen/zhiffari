<?php
// ---------- Umum ----------
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function rupiah($n) { return 'Rp ' . number_format((float)$n, 0, ',', '.'); }
function redirect($u) { header('Location: ' . $u); exit; }
function url($p = '') { return BASE_URL . '/' . ltrim($p, '/'); }
function tgl($d, $jam = true) { return $d ? date($jam ? 'd/m/Y H:i' : 'd/m/Y', strtotime($d)) : '-'; }

function setting($k, $d = '') {
    static $c = null;
    if ($c === null) {
        $c = [];
        foreach (rows('SELECT kunci,nilai FROM pengaturan') as $r) $c[$r['kunci']] = $r['nilai'];
    }
    return $c[$k] ?? $d;
}

function flash($t = null, $m = null) {
    if ($t !== null) { $_SESSION['flash'][] = ['t' => $t, 'm' => $m]; return null; }
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}
function render_flash() {
    foreach (flash() as $f) echo '<div class="alert alert-' . e($f['t']) . '">' . e($f['m']) . '</div>';
}

// ---------- CSRF ----------
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field() { return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">'; }
function csrf_check() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['_csrf'] ?? '')) {
            http_response_code(419);
            die('Sesi kedaluwarsa. Silakan kembali, muat ulang halaman, lalu coba lagi.');
        }
    }
}

// ---------- Slug, upload ----------
function slugify($s) {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    $s = trim($s, '-');
    return $s !== '' ? $s : 'item';
}
function unique_slug($table, $nama, $ignoreId = 0) {
    $base = slugify($nama); $slug = $base; $i = 2;
    while (val("SELECT COUNT(*) FROM `$table` WHERE slug=? AND id<>?", [$slug, $ignoreId])) {
        $slug = $base . '-' . $i++;
    }
    return $slug;
}
function upload_image($field, $old = '') {
    if (empty($_FILES[$field]['name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return $old;
    $f = $_FILES[$field];
    if ($f['size'] > 3 * 1024 * 1024) { flash('danger', 'Ukuran gambar maksimal 3 MB.'); return $old; }
    $info = @getimagesize($f['tmp_name']);
    $ok = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    if (!$info || !isset($ok[$info['mime']])) { flash('danger', 'Format gambar harus JPG, PNG, WEBP, atau GIF.'); return $old; }
    if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);
    $name = bin2hex(random_bytes(8)) . '.' . $ok[$info['mime']];
    if (move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $name)) {
        if ($old && is_file(UPLOAD_DIR . $old)) @unlink(UPLOAD_DIR . $old);
        return $name;
    }
    flash('danger', 'Gagal menyimpan gambar. Periksa izin folder uploads/.');
    return $old;
}
function delete_image($f) { if ($f && is_file(UPLOAD_DIR . $f)) @unlink(UPLOAD_DIR . $f); }
function img($f) {
    return ($f && is_file(UPLOAD_DIR . $f)) ? url('uploads/' . $f) : url('assets/img/placeholder.svg');
}

// ---------- Produk ----------
function harga_efektif($p) {
    return ($p['harga_diskon'] > 0 && $p['harga_diskon'] < $p['harga']) ? $p['harga_diskon'] : $p['harga'];
}
function daftar_ukuran($p) {
    $u = array_filter(array_map('trim', explode(',', (string)$p['ukuran'])));
    return array_values($u);
}
function product_card($p) {
    $h = harga_efektif($p);
    $disc = $h < $p['harga'];
    $pct = $disc ? round((1 - $h / $p['harga']) * 100) : 0;
    ob_start(); ?>
    <a class="card" href="<?= url('detail.php?slug=' . urlencode($p['slug'])) ?>">
        <div class="card-img">
            <img src="<?= e(img($p['gambar'])) ?>" alt="<?= e($p['nama']) ?>" loading="lazy">
            <?php if ($disc): ?><span class="badge badge-sale">-<?= $pct ?>%</span><?php endif; ?>
            <?php if ($p['stok'] <= 0): ?><span class="badge badge-out">Habis</span><?php endif; ?>
        </div>
        <div class="card-body">
            <h3><?= e($p['nama']) ?></h3>
            <div class="price">
                <strong><?= rupiah($h) ?></strong>
                <?php if ($disc): ?><s><?= rupiah($p['harga']) ?></s><?php endif; ?>
            </div>
            <small class="muted">Terjual <?= (int)$p['terjual'] ?></small>
        </div>
    </a>
    <?php return ob_get_clean();
}
function pager($total, $per, $page) {
    $pages = max(1, (int)ceil($total / $per));
    if ($pages <= 1) return '';
    $qs = $_GET;
    $h = '<div class="pager">';
    for ($i = 1; $i <= $pages; $i++) {
        $qs['page'] = $i;
        $h .= '<a class="' . ($i == $page ? 'active' : '') . '" href="?' . e(http_build_query($qs)) . '">' . $i . '</a>';
    }
    return $h . '</div>';
}

// ---------- Status pesanan ----------
function status_list() {
    return [
        'menunggu_pembayaran' => 'Menunggu Pembayaran',
        'diproses' => 'Diproses',
        'dikirim' => 'Dikirim',
        'selesai' => 'Selesai',
        'dibatalkan' => 'Dibatalkan',
    ];
}
function status_badge($s) {
    $l = status_list();
    return '<span class="st st-' . e($s) . '">' . e($l[$s] ?? $s) . '</span>';
}
function ubah_status_pesanan($id, $baru) {
    $p = row('SELECT * FROM pesanan WHERE id=?', [$id]);
    if (!$p || !isset(status_list()[$baru])) return false;
    if ($p['status'] === 'dibatalkan') return false; // pesanan batal tidak dapat diaktifkan lagi
    db()->beginTransaction();
    try {
        if ($baru === 'dibatalkan') {
            foreach (rows('SELECT produk_id,qty FROM pesanan_item WHERE pesanan_id=?', [$id]) as $it) {
                if ($it['produk_id']) q('UPDATE produk SET stok=stok+?, terjual=GREATEST(terjual-?,0) WHERE id=?', [$it['qty'], $it['qty'], $it['produk_id']]);
            }
        }
        q('UPDATE pesanan SET status=? WHERE id=?', [$baru, $id]);
        db()->commit();
    } catch (Exception $ex) { db()->rollBack(); return false; }
    return true;
}

// ---------- Keranjang ----------
function cart() { return $_SESSION['cart'] ?? []; }
function cart_count() { return array_sum(cart()); }
function cart_items() {
    $items = [];
    foreach (cart() as $k => $qty) {
        $parts = explode('|', $k, 2);
        $pid = (int)$parts[0]; $uk = $parts[1] ?? '';
        $p = row('SELECT * FROM produk WHERE id=? AND aktif=1', [$pid]);
        if (!$p || $p['stok'] <= 0) { unset($_SESSION['cart'][$k]); continue; }
        $qty = max(1, min((int)$qty, (int)$p['stok']));
        $_SESSION['cart'][$k] = $qty;
        $h = harga_efektif($p);
        $items[] = ['key' => $k, 'p' => $p, 'ukuran' => $uk, 'qty' => $qty, 'harga' => $h, 'total' => $h * $qty];
    }
    return $items;
}
function cart_subtotal($items) { return array_sum(array_column($items, 'total')); }
function hitung_ongkir($sub) {
    $min = (float)setting('gratis_ongkir_min', 0);
    if ($sub <= 0) return 0;
    if ($min > 0 && $sub >= $min) return 0;
    return (float)setting('ongkir', 0);
}
function metode_bayar_list() {
    $out = [];
    foreach (preg_split('/\r?\n/', (string)setting('metode_bayar')) as $l) {
        $l = trim($l); if ($l === '') continue;
        $x = explode('|', $l, 2);
        $out[] = ['nama' => trim($x[0]), 'ket' => trim($x[1] ?? '')];
    }
    return $out;
}

// ---------- Pengguna & peran ----------
function role_label($r = null) {
    $l = [
        'super_admin' => 'Super Admin',
        'admin' => 'Admin Toko',
        'staf_produk' => 'Staf Produk',
        'staf_pesanan' => 'Staf Pesanan',
        'pelanggan' => 'Pelanggan',
    ];
    return $r === null ? $l : ($l[$r] ?? $r);
}
function current_user() {
    static $u = false;
    if ($u === false) {
        $u = null;
        if (!empty($_SESSION['uid'])) {
            $u = row('SELECT * FROM users WHERE id=? AND aktif=1', [$_SESSION['uid']]) ?: null;
            if (!$u) unset($_SESSION['uid']);
        }
    }
    return $u;
}
function login_user($u) {
    session_regenerate_id(true);
    $_SESSION['uid'] = $u['id'];
}
function role_perms() {
    return [
        'super_admin' => ['*'],
        'admin' => ['dashboard', 'produk', 'kategori', 'pesanan', 'banner', 'halaman', 'pengaturan', 'laporan', 'pelanggan'],
        'staf_produk' => ['dashboard', 'produk', 'kategori', 'banner'],
        'staf_pesanan' => ['dashboard', 'pesanan', 'laporan', 'pelanggan'],
    ];
}
function can($perm) {
    $u = current_user();
    if (!$u) return false;
    $r = role_perms()[$u['role']] ?? [];
    return in_array('*', $r) || in_array($perm, $r);
}
function require_admin($perm = 'dashboard') {
    $u = current_user();
    if (!$u || $u['role'] === 'pelanggan') redirect(url('admin/login.php'));
    if (!can($perm)) {
        http_response_code(403);
        $title = 'Akses Ditolak';
        require __DIR__ . '/../admin/_403.php';
        exit;
    }
}
