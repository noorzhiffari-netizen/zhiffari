<?php
require_once __DIR__ . '/includes/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aksi = $_POST['aksi'] ?? '';
    if ($aksi === 'tambah') {
        $p = row('SELECT * FROM produk WHERE id=? AND aktif=1', [(int)($_POST['id'] ?? 0)]);
        $uk = trim($_POST['ukuran'] ?? '');
        $qty = max(1, (int)($_POST['qty'] ?? 1));
        if (!$p || $p['stok'] <= 0) { flash('danger', 'Produk tidak tersedia.'); redirect(url('produk.php')); }
        $list = daftar_ukuran($p);
        if ($list && !in_array($uk, $list, true)) { flash('danger', 'Silakan pilih ukuran terlebih dahulu.'); redirect(url('detail.php?slug=' . urlencode($p['slug']))); }
        if (!$list) $uk = '';
        $key = $p['id'] . '|' . $uk;
        $_SESSION['cart'][$key] = min((int)$p['stok'], ($_SESSION['cart'][$key] ?? 0) + $qty);
        if (!empty($_POST['langsung'])) redirect(url('checkout.php'));
        flash('success', '"' . $p['nama'] . '" ditambahkan ke keranjang.');
        redirect(url('keranjang.php'));
    }
    if ($aksi === 'ubah') {
        foreach (($_POST['qty'] ?? []) as $key => $q) {
            if (isset($_SESSION['cart'][$key])) {
                if ((int)$q <= 0) unset($_SESSION['cart'][$key]); else $_SESSION['cart'][$key] = (int)$q;
            }
        }
        flash('success', 'Keranjang diperbarui.');
    }
    if ($aksi === 'hapus') { unset($_SESSION['cart'][$_POST['key'] ?? '']); }
    redirect(url('keranjang.php'));
}

$pageTitle = 'Keranjang Belanja';
$items = cart_items();
$sub = cart_subtotal($items);
$ongkir = hitung_ongkir($sub);
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<h1 class="page-title">Keranjang Belanja</h1>
<?php if (!$items): ?>
    <div class="panel" style="margin-top:20px">Keranjang Anda masih kosong. <a href="<?= url('produk.php') ?>"><b>Mulai belanja</b></a></div>
<?php else: ?>
<div class="two">
    <div class="panel">
        <form method="post" id="fcart">
            <?= csrf_field() ?><input type="hidden" name="aksi" value="ubah">
            <table class="tbl resp">
                <thead><tr><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Total</th><th></th></tr></thead>
                <?php foreach ($items as $it): $p = $it['p']; ?>
                <tr>
                    <td><div style="display:flex;gap:10px;align-items:center">
                        <img class="thumb" src="<?= e(img($p['gambar'])) ?>" alt="">
                        <div><a href="<?= url('detail.php?slug=' . urlencode($p['slug'])) ?>"><b><?= e($p['nama']) ?></b></a>
                        <?php if ($it['ukuran']): ?><br><small class="muted">Ukuran: <?= e($it['ukuran']) ?></small><?php endif; ?></div></div></td>
                    <td><?= rupiah($it['harga']) ?></td>
                    <td><div class="qty"><button type="button" data-d="-">&minus;</button><input type="number" name="qty[<?= e($it['key']) ?>]" value="<?= (int)$it['qty'] ?>" min="0" max="<?= (int)$p['stok'] ?>"><button type="button" data-d="+">+</button></div></td>
                    <td><b><?= rupiah($it['total']) ?></b></td>
                    <td><button class="btn btn-sm btn-outline" form="del<?= md5($it['key']) ?>" type="submit">Hapus</button></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <p><button class="btn btn-sm" type="submit">Perbarui Keranjang</button></p>
        </form>
        <?php foreach ($items as $it): ?>
            <form id="del<?= md5($it['key']) ?>" method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="key" value="<?= e($it['key']) ?>"></form>
        <?php endforeach; ?>
    </div>
    <div class="panel">
        <h3>Ringkasan</h3>
        <div class="sum-row"><span>Subtotal</span><span><?= rupiah($sub) ?></span></div>
        <div class="sum-row"><span>Ongkos kirim</span><span><?= $ongkir > 0 ? rupiah($ongkir) : '<b style="color:#16a34a">GRATIS</b>' ?></span></div>
        <div class="sum-row total"><span>Total</span><span><?= rupiah($sub + $ongkir) ?></span></div>
        <a class="btn btn-accent btn-block" style="margin-top:14px" href="<?= url('checkout.php') ?>">Lanjut ke Checkout</a>
    </div>
</div>
<?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
