<?php
require_once __DIR__ . '/includes/init.php';
if (current_user()) redirect(url('akun.php'));
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $u = row('SELECT * FROM users WHERE email=? AND aktif=1', [$email]);
    if ($u && password_verify($_POST['password'] ?? '', $u['password'])) {
        login_user($u);
        if ($u['role'] !== 'pelanggan') redirect(url('admin/index.php'));
        $to = $_SESSION['after_login'] ?? url('akun.php');
        unset($_SESSION['after_login']);
        redirect($to);
    }
    $err = 'Email atau password salah.';
}
$pageTitle = 'Masuk';
require __DIR__ . '/includes/header.php';
?>
<div class="container">
<div class="panel auth">
    <h2>Masuk ke Akun</h2>
    <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <div class="form-row"><label>Email</label><input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></div>
        <div class="form-row"><label>Password</label><input type="password" name="password" required></div>
        <button class="btn btn-block" type="submit">Masuk</button>
    </form>
    <p style="text-align:center">Belum punya akun? <a href="<?= url('register.php') ?>"><b>Daftar</b></a></p>
</div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
